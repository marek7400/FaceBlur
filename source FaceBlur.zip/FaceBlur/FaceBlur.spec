# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['face_blur_v36_multi_model.py'],
    pathex=[],
    binaries=[],
    datas=[('face_detection_yunet_2023mar.onnx', '.'), ('scrfd_500m.onnx', '.'), ('scrfd_2.5g.onnx', '.'), ('yolov8n-face.onnx', '.'), ('haarcascade_frontalface_default.xml', '.')],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='FaceBlur',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['faceblur.ico'],
)

@echo off
chcp 65001 >nul
title Kompilacja FaceBlurTool do 1 pliku EXE

echo [1/3] Sprawdzanie obecności modeli ONNX...
if not exist "face_detection_yunet_2023mar.onnx" (
    echo [BLAD] Brak pliku: face_detection_yunet_2023mar.onnx
    goto error
)
if not exist "scrfd_500m.onnx" (
    echo [BLAD] Brak pliku: scrfd_500m.onnx
    goto error
)
if not exist "scrfd_2.5g.onnx" (
    echo [BLAD] Brak pliku: scrfd_2.5g.onnx
    goto error
)
if not exist "yolov8n-face.onnx" (
    echo [BLAD] Brak pliku: yolov8n-face.onnx
    goto error
)

echo [2/3] Upewnianie sie o instalacji PyInstaller...
pip install -q pyinstaller

echo [3/3] Pakowanie programu i zaszywanie wszystkich modeli w 1 plik EXE...
pyinstaller --noconsole --onefile --icon=faceblur.ico ^
  --name="FaceBlur" ^
  --add-data "face_detection_yunet_2023mar.onnx;." ^
  --add-data "scrfd_500m.onnx;." ^
  --add-data "scrfd_2.5g.onnx;." ^
  --add-data "yolov8n-face.onnx;." ^
  --add-data "haarcascade_frontalface_default.xml;." ^
  face_blur_v36_multi_model.py

if %errorlevel% neq 0 goto error

echo =======================================================
echo SUKCES! Gotowy plik znajdziesz w folderze: dist\FaceBlur.exe
echo Wszystkie 4 modele zostały zaszyte wewnątrz pliku.
echo =======================================================
pause
exit /b 0

:error
echo =======================================================
echo Wystąpił błąd podczas sprawdzania plików lub kompilacji.
echo =======================================================
pause
exit /b 1
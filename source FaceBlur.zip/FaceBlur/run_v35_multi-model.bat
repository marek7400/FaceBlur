@echo off
title Face Blur Tool V29
echo Instalacja zaleznosci...
pip install -q -r requirements.txt
echo Uruchamianie aplikacji...
python face_blur_v35_multi_model.py
pause
import sys
import os
os.environ['OPENCV_LOG_LEVEL'] = 'SILENT'
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import cv2
import numpy as np
import threading
import webbrowser
from PIL import Image, ImageTk
import ssl

try:
    ssl._create_default_https_context = ssl._create_unverified_context
except Exception:
    pass

try:
    cv2.utils.logging.setLogLevel(cv2.utils.logging.LOG_LEVEL_SILENT)
except Exception:
    pass


class FaceDetector:
    """
    Uniwersalny detektor twarzy obsługujący 4 modele ONNX:
    1. YuNet (OpenCV FaceDetectorYN)
    2. SCRFD 500M
    3. SCRFD 2.5G
    4. YOLO-Face Nano
    + Haar Cascade jako wbudowany fallback.
    Kompatybilny z PyInstaller (obsługa sys._MEIPASS oraz katalogu obok .exe).
    """
    def __init__(self):
        self.current_model_type = "YuNet"
        self.net = None
        self.model_path = ""
        self.model_files_map = {
            "YuNet": [
                "face_detection_yunet_2026may.onnx",
                "face_detection_yunet_2023mar.onnx",
                "yunet.onnx"
            ],
            "SCRFD 500M": [
                "scrfd_500m_bnkps.onnx",
                "scrfd_500m.onnx",
                "500m.onnx",
                "det_500m.onnx"
            ],
            "SCRFD 2.5G": [
                "scrfd_2.5g_bnkps.onnx",
                "scrfd_2.5g.onnx",
                "2.5g_bnkps.onnx",
                "det_2.5g.onnx"
            ],
            "YOLO-Face (Nano)": [
                "yolov8n-face.onnx",
                "yolov8n_face.onnx",
                "yolo-face.onnx",
                "model.onnx"
            ]
        }
        self.load_model("YuNet")

    def find_model_path(self, model_name):
        candidates = self.model_files_map.get(model_name, [])
        
        # Obsługa ścieżek dla PyInstaller (zaszyte wewnątrz .exe oraz folder obok .exe)
        internal_dir = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
        exe_dir = os.path.dirname(sys.executable) if getattr(sys, 'frozen', False) else os.path.dirname(os.path.abspath(__file__))

        search_dirs = [
            internal_dir,                                              # Pliki spakowane do wnętrza pliku .exe
            exe_dir,                                                   # Folder, w którym użytkownik umieścił plik .exe
            os.path.dirname(os.path.abspath(__file__)),                # Folder skryptu Python
            os.getcwd(),                                               # Katalog roboczy
            os.path.join(os.path.expanduser("~"), ".face_detector")    # Katalog domowy
        ]
        
        for sdir in search_dirs:
            for fname in candidates:
                full_path = os.path.join(sdir, fname)
                if os.path.exists(full_path):
                    return full_path
        return ""

    def load_model(self, model_name, custom_path=""):
        self.current_model_type = model_name
        self.net = None
        
        path = custom_path if custom_path and os.path.exists(custom_path) else self.find_model_path(model_name)
        self.model_path = path

        if not path:
            print(f"[DETECTOR] Brak pliku dla {model_name}. Używam Haar Cascade.")
            self._load_haar()
            return False

        try:
            if model_name == "YuNet":
                self.net = cv2.FaceDetectorYN_create(path, "", (320, 320), 0.5, 0.3, 5000)
                print(f"[DETECTOR] Załadowano YuNet: {path}")
            elif "SCRFD" in model_name:
                self.net = cv2.dnn.readNetFromONNX(path)
                print(f"[DETECTOR] Załadowano {model_name}: {path}")
            elif "YOLO" in model_name:
                self.net = cv2.dnn.readNetFromONNX(path)
                print(f"[DETECTOR] Załadowano YOLO-Face: {path}")
            return True
        except Exception as e:
            print(f"[DETECTOR] Błąd ładowania {model_name}: {e}")
            self._load_haar()
            return False

    def _load_haar(self):
        internal_dir = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
        exe_dir = os.path.dirname(sys.executable) if getattr(sys, 'frozen', False) else os.path.dirname(os.path.abspath(__file__))
        
        for hp in [
            os.path.join(internal_dir, "haarcascade_frontalface_default.xml"),
            os.path.join(exe_dir, "haarcascade_frontalface_default.xml"),
            os.path.join(os.path.dirname(__file__), "haarcascade_frontalface_default.xml"),
            os.path.join(cv2.data.haarcascades, "haarcascade_frontalface_default.xml") if hasattr(cv2, 'data') else "",
        ]:
            if hp and os.path.exists(hp):
                try:
                    d = cv2.CascadeClassifier(hp)
                    if not d.empty():
                        self.net = d
                        self.current_model_type = "Haar Cascade"
                        self.model_path = hp
                        print(f"[DETECTOR] Załadowano Haar fallback: {hp}")
                        return
                except Exception:
                    pass
        self.net = None

    def detect(self, frame):
        faces = []
        if self.net is None or frame is None:
            return faces

        h, w = frame.shape[:2]
        try:
            if self.current_model_type == "YuNet":
                self.net.setInputSize((w, h))
                _, res = self.net.detect(frame)
                if res is not None:
                    for det in res:
                        x, y, bw, bh = map(int, det[:4])
                        if bw > 10 and bh > 10:
                            faces.append((x, y, bw, bh))

            elif "SCRFD" in self.current_model_type:
                faces = self._detect_scrfd(frame, w, h)

            elif "YOLO" in self.current_model_type:
                faces = self._detect_yolo(frame, w, h)

            elif self.current_model_type == "Haar Cascade":
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                rects = self.net.detectMultiScale(gray, 1.1, 4, minSize=(20, 20))
                for (x, y, bw, bh) in rects:
                    faces.append((int(x), int(y), int(bw), int(bh)))

        except Exception as e:
            print(f"detect error ({self.current_model_type}): {e}")

        return faces

    def _detect_scrfd(self, frame, orig_w, orig_h):
        input_size = (640, 640)
        blob = cv2.dnn.blobFromImage(frame, 1.0 / 128.0, input_size, (127.5, 127.5, 127.5), swapRB=True)
        self.net.setInput(blob)

        out_names = self.net.getUnconnectedOutLayersNames()
        outs = self.net.forward(out_names)

        bboxes_list = []
        scores_list = []
        strides = [8, 16, 32]
        
        score_tensors = {}
        bbox_tensors = {}
        for out in outs:
            shape = out.shape
            if len(shape) == 3:
                out = out[0]
            cols = out.shape[-1]
            rows = out.shape[0]
            if cols == 1:
                score_tensors[rows] = out
            elif cols == 4:
                bbox_tensors[rows] = out

        scale_x = orig_w / 640.0
        scale_y = orig_h / 640.0

        for stride in strides:
            feat_w = 640 // stride
            feat_h = 640 // stride
            num_anchors = 2
            expected_rows = feat_w * feat_h * num_anchors

            if expected_rows not in score_tensors or expected_rows not in bbox_tensors:
                continue

            scores = score_tensors[expected_rows]
            bboxes = bbox_tensors[expected_rows]

            grid_x = np.tile(np.arange(feat_w), feat_h) * stride
            grid_y = np.repeat(np.arange(feat_h), feat_w) * stride
            anchor_centers = np.stack([grid_x, grid_y], axis=-1).astype(np.float32)
            anchor_centers = np.repeat(anchor_centers, num_anchors, axis=0)

            mask = scores[:, 0] > 0.45
            if not np.any(mask):
                continue

            sub_scores = scores[mask, 0]
            sub_bboxes = bboxes[mask]
            sub_centers = anchor_centers[mask]

            x1 = (sub_centers[:, 0] - sub_bboxes[:, 0] * stride) * scale_x
            y1 = (sub_centers[:, 1] - sub_bboxes[:, 1] * stride) * scale_y
            x2 = (sub_centers[:, 0] + sub_bboxes[:, 2] * stride) * scale_x
            y2 = (sub_centers[:, 1] + sub_bboxes[:, 3] * stride) * scale_y

            for i in range(len(sub_scores)):
                bw = int(x2[i] - x1[i])
                bh = int(y2[i] - y1[i])
                if bw > 10 and bh > 10:
                    bboxes_list.append([int(x1[i]), int(y1[i]), bw, bh])
                    scores_list.append(float(sub_scores[i]))

        if not bboxes_list:
            return []

        indices = cv2.dnn.NMSBoxes(bboxes_list, scores_list, 0.45, 0.4)
        faces = []
        if len(indices) > 0:
            for idx in np.array(indices).flatten():
                faces.append(tuple(bboxes_list[idx]))
        return faces

    def _detect_yolo(self, frame, orig_w, orig_h):
        input_size = (640, 640)
        blob = cv2.dnn.blobFromImage(frame, 1.0 / 255.0, input_size, swapRB=True, crop=False)
        self.net.setInput(blob)
        preds = self.net.forward()
        
        if len(preds.shape) == 3:
            preds = preds[0]
        if preds.shape[0] < preds.shape[1]:
            preds = preds.T

        boxes = []
        confidences = []
        scale_x = orig_w / 640.0
        scale_y = orig_h / 640.0

        for row in preds:
            conf = float(row[4])
            if conf > 0.45:
                cx, cy, w, h = row[0] * scale_x, row[1] * scale_y, row[2] * scale_x, row[3] * scale_y
                x = int(cx - w / 2)
                y = int(cy - h / 2)
                bw = int(w)
                bh = int(h)
                if bw > 10 and bh > 10:
                    boxes.append([x, y, bw, bh])
                    confidences.append(conf)

        if not boxes:
            return []

        indices = cv2.dnn.NMSBoxes(boxes, confidences, 0.45, 0.4)
        faces = []
        if len(indices) > 0:
            for idx in np.array(indices).flatten():
                faces.append(tuple(boxes[idx]))
        return faces


class FaceBlurApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Face Blur Tool - github.com/marek7400")

        try:
            self.root.state('zoomed')
        except Exception:
            try:
                self.root.attributes('-zoomed', True)
            except Exception:
                self.root.geometry(f"{self.root.winfo_screenwidth()}x{self.root.winfo_screenheight()}+0+0")

        self.cap = None
        self.is_image_mode = False
        self.total_frames = 0
        self.fps = 25
        self.w = self.h = 0
        self.current_idx = 0
        self.input_path = ""
        self.faces_current = []
        
        self.trackers = []
        self.next_id = 1
        self.next_face_id = 1
        self.is_tracking_paused = False

        # Zoom i Pan
        self.zoom_level = 1.0
        self.view_cx = 0.0
        self.view_cy = 0.0
        self.is_panning = False
        self.is_shift_panning = False
        self.is_right_panning = False
        self.right_pan_dragged = False
        self.pan_start_x = 0
        self.pan_start_y = 0
        self.pan_start_cx = 0.0
        self.pan_start_cy = 0.0

        self.disp_scale = 1.0
        self.disp_w = 0
        self.disp_h = 0
        self.disp_off_x = 0
        self.disp_off_y = 0
        self.crop_x0 = 0
        self.crop_y0 = 0
        self.crop_w = 0
        self.crop_h = 0

        self.orig_frame_cache = None
        self.face_detector = FaceDetector()
        
        # Mysz i interaktywna zmiana kształtu / przesuwanie ramki
        self.is_mouse_down = False
        self.has_dragged = False
        self.draw_start = None
        self.draw_rect = None

        # Rysowanie wielokątem (LINE)
        self.polygon_pts = []
        self.current_mouse_orig = None

        self.hover_action = None
        self.hover_tracker = None
        self.active_drag_action = None
        self.active_drag_tracker = None
        self.drag_start_event_x = 0
        self.drag_start_event_y = 0
        self.drag_start_bbox = None
        self.drag_start_rel_poly = None

        # Checkboxy domyślne
        self.stop_on_loss_var = tk.BooleanVar(value=True)
        self.blackbox_var = tk.BooleanVar(value=False)
        self.line_var = tk.BooleanVar(value=False)
        self.circle_var = tk.BooleanVar(value=True)
        self.pixel_mode_var = tk.BooleanVar(value=False)

        self.frame_cache = {}
        self.cache_size = 150
        self.slider_dragging = False

        self._last_resize_w = 0
        self._last_resize_h = 0

        # --- GÓRNY PASEK AKCJI ---
        top = tk.Frame(root)
        top.pack(fill=tk.X, padx=8, pady=5)
        
        tk.Button(top, text="Wybierz wideo", command=self.choose_file, bg="#4CAF50", fg="white", font=("Arial", 10, "bold")).pack(side=tk.LEFT, padx=3)
        tk.Button(top, text="Wybierz zdjęcie", command=self.choose_image, bg="#388E3C", fg="white", font=("Arial", 10, "bold")).pack(side=tk.LEFT, padx=3)
        
        # Link do GitHub
        link_lbl = tk.Label(top, text="GitHub: marek7400", fg="#1976D2", cursor="hand2", font=("Arial", 9, "bold", "underline"))
        link_lbl.pack(side=tk.LEFT, padx=6)
        link_lbl.bind("<Button-1>", lambda e: webbrowser.open("https://github.com/marek7400?tab=repositories"))

        tk.Label(top, text="Model:", font=("Arial", 9, "bold")).pack(side=tk.LEFT, padx=(6, 2))
        self.model_combo = ttk.Combobox(top, values=["YuNet", "SCRFD 500M", "SCRFD 2.5G", "YOLO-Face (Nano)"], state="readonly", width=15)
        self.model_combo.set("YuNet")
        self.model_combo.pack(side=tk.LEFT, padx=2)
        self.model_combo.bind("<<ComboboxSelected>>", self.on_model_changed)
        tk.Button(top, text="Wskaż...", command=self.browse_model_file, font=("Arial", 8)).pack(side=tk.LEFT, padx=2)

        tk.Button(top, text="Zamaż wszystkie zielone", command=self.add_all_detected_faces, bg="#FF9800", fg="white", font=("Arial", 9, "bold")).pack(side=tk.LEFT, padx=4)

        self.btn_pause = tk.Button(top, text="⏸ PAUSE", command=self.pause_tracking, bg="#795548", fg="white", font=("Arial", 9, "bold"))
        self.btn_pause.pack(side=tk.LEFT, padx=3)

        self.btn_resume = tk.Button(top, text="▶ RESUME", command=self.resume_tracking, bg="#009688", fg="white", font=("Arial", 9, "bold"))
        self.btn_resume.pack(side=tk.LEFT, padx=2)

        self.pause_indicator = tk.Label(top, text="● AKTYWNE", fg="#4CAF50", font=("Arial", 9, "bold"))
        self.pause_indicator.pack(side=tk.LEFT, padx=5)

        tk.Checkbutton(top, text="CIRCLE (owal)", variable=self.circle_var, font=("Arial", 9, "bold"), bg="#E0F7FA", command=self.refresh).pack(side=tk.LEFT, padx=3)
        tk.Checkbutton(top, text="BLACKBOX", variable=self.blackbox_var, bg="black", fg="white", selectcolor="#555", font=("Arial", 9, "bold"), command=self.refresh).pack(side=tk.LEFT, padx=3)
        tk.Checkbutton(top, text="LINE (wielokąt)", variable=self.line_var, font=("Arial", 9, "bold"), bg="#FFF3E0", command=self.on_line_toggle).pack(side=tk.LEFT, padx=3)
        tk.Checkbutton(top, text="Stop gdy zgubi", variable=self.stop_on_loss_var, font=("Arial", 9)).pack(side=tk.LEFT, padx=3)

        tk.Button(top, text="🔍 ZOOM 1:1", command=self.reset_zoom, bg="#607D8B", fg="white", font=("Arial", 9, "bold")).pack(side=tk.LEFT, padx=4)
        tk.Button(top, text="Cofnij", command=self.remove_last, bg="#9C27B0", fg="white", font=("Arial", 9)).pack(side=tk.LEFT, padx=3)
        tk.Button(top, text="Wyczyść", command=self.clear_trackers, bg="#f44336", fg="white", font=("Arial", 9)).pack(side=tk.LEFT, padx=2)
        tk.Button(top, text="Eksportuj / Zapisz", command=self.export_media, bg="#2196F3", fg="white", font=("Arial", 10, "bold")).pack(side=tk.LEFT, padx=6)

        # --- GŁÓWNY PANEL ---
        main = tk.Frame(root)
        main.pack(fill=tk.BOTH, expand=True, padx=5, pady=2)
        
        left = tk.Frame(main)
        left.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.video_frame = tk.Frame(left, bg="black")
        self.video_frame.pack(fill=tk.BOTH, expand=True)
        
        self.video_label = tk.Label(
            self.video_frame, bg="black",
            text="EDYCJA I ZAMAZYWANIE:\n\n"
                 "• Najedź na ŚRODEK ramki (ikona 4 strzałek) i przeciągnij, aby przesunąć ramkę\n"
                 "• Najedź na KRAWĘDŹ lub NAROŻNIK ramki, aby zmienić jej rozmiar\n"
                 "• Checkbox LINE: klikaj kolejne punkty, 2x klik zamyka kształt wielokątem\n"
                 "• Scroll myszki: Zoom | Prawy przycisk: Przesuwanie widoku (Pan) przy Zoomie / Usunięcie ramki\n"
                 "• Klik lewym: AUTO | Przeciągnięcie lewym: MANUAL",
            fg="white", font=("Arial", 12), justify=tk.LEFT
        )
        self.video_label.pack(fill=tk.BOTH, expand=True)

        self.video_label.bind("<Motion>", self.on_mouse_motion)
        self.video_label.bind("<Button-1>", self.on_mouse_down)
        self.video_label.bind("<Double-Button-1>", self.on_mouse_double_click)
        self.video_label.bind("<B1-Motion>", self.on_mouse_drag)
        self.video_label.bind("<ButtonRelease-1>", self.on_mouse_up)

        self.video_label.bind("<Button-3>", self.on_right_down)
        self.video_label.bind("<B3-Motion>", self.on_right_drag)
        self.video_label.bind("<ButtonRelease-3>", self.on_right_up)

        self.video_label.bind("<Button-2>", self.on_pan_start)
        self.video_label.bind("<B2-Motion>", self.on_pan_drag)
        self.video_label.bind("<ButtonRelease-2>", self.on_pan_end)

        self.video_label.bind("<MouseWheel>", self.on_mouse_wheel)
        self.video_label.bind("<Button-4>", self.on_mouse_wheel)
        self.video_label.bind("<Button-5>", self.on_mouse_wheel)

        right_list = tk.Frame(main, width=330, bg="#f5f5f5")
        right_list.pack(side=tk.RIGHT, fill=tk.Y, padx=5)
        right_list.pack_propagate(False)
        
        self.mode_label = tk.Label(right_list, text="AKTYWNY DETEKTOR:\nYuNet", bg="#BBDEFB", font=("Arial", 10, "bold"), justify=tk.LEFT)
        self.mode_label.pack(fill=tk.X, pady=4)
        
        self.info_label = tk.Label(right_list, text="Brak wideo / zdjęcia", bg="#f5f5f5", font=("Arial", 9), justify=tk.LEFT, wraplength=310)
        self.info_label.pack(fill=tk.X, pady=4)
        
        tk.Label(right_list, text="Segmenty i Oś Czasu:", bg="#f5f5f5", font=("Arial", 9, "bold")).pack(pady=4)
        
        self.tracker_list_canvas = tk.Canvas(right_list, bg="#f5f5f5", highlightthickness=0)
        self.scrollbar = tk.Scrollbar(right_list, orient="vertical", command=self.tracker_list_canvas.yview)
        self.tracker_list_frame = tk.Frame(self.tracker_list_canvas, bg="#f5f5f5")
        
        self.tracker_list_frame.bind("<Configure>", lambda e: self.tracker_list_canvas.configure(scrollregion=self.tracker_list_canvas.bbox("all")))
        self.tracker_list_canvas.create_window((0, 0), window=self.tracker_list_frame, anchor="nw")
        self.tracker_list_canvas.configure(yscrollcommand=self.scrollbar.set)
        
        self.scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.tracker_list_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # --- DOLNY PASEK STEROWANIA ---
        ctrl = tk.Frame(root)
        ctrl.pack(fill=tk.X, padx=8, pady=3)

        self.btn_first = tk.Button(ctrl, text="|<< Początek", command=self.jump_to_start, bg="#37474F", fg="white", font=("Arial", 9, "bold"))
        self.btn_first.pack(side=tk.LEFT, padx=3)

        self.slider = tk.Scale(ctrl, from_=0, to=100, orient=tk.HORIZONTAL, label="Oś czasu (lewo/prawo = 1, Shift = 10, góra = +30 klatek, dół = -30 klatek)", length=900, command=self.on_slider_drag)
        self.slider.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=4)
        self.slider.bind("<ButtonPress-1>", lambda e: setattr(self, 'slider_dragging', True))
        self.slider.bind("<ButtonRelease-1>", self.on_slider_release)

        self.btn_last = tk.Button(ctrl, text="Koniec >>|", command=self.jump_to_end, bg="#37474F", fg="white", font=("Arial", 9, "bold"))
        self.btn_last.pack(side=tk.LEFT, padx=3)

        self.frame_entry = tk.Entry(ctrl, width=7)
        self.frame_entry.pack(side=tk.LEFT, padx=4)
        self.frame_entry.bind("<Return>", self.on_frame_entry)
        self.total_label = tk.Label(ctrl, text="/ 0")
        self.total_label.pack(side=tk.LEFT, padx=2)

        right = tk.Frame(root)
        right.pack(fill=tk.X, padx=8, pady=3)
        tk.Label(right, text="Siła rozmycia:").pack(side=tk.LEFT)
        self.blur_slider = tk.Scale(right, from_=15, to=151, orient=tk.HORIZONTAL, resolution=2, command=lambda v: self.refresh())
        self.blur_slider.set(75)
        self.blur_slider.pack(side=tk.LEFT, padx=5)

        tk.Checkbutton(right, text="PIXEL MODE", variable=self.pixel_mode_var, font=("Arial", 9, "bold"), command=self.refresh).pack(side=tk.LEFT, padx=6)
        
        tk.Label(right, text="Tolerancja skoku (px):").pack(side=tk.LEFT, padx=6)
        self.jump_slider = tk.Scale(right, from_=10, to=300, orient=tk.HORIZONTAL)
        self.jump_slider.set(130)
        self.jump_slider.pack(side=tk.LEFT, padx=2)

        self.progress = ttk.Progressbar(root, orient="horizontal", mode="determinate")
        self.progress.pack(fill=tk.X, padx=8, pady=2)
        self.status_label = tk.Label(root, text="Wybierz plik wideo lub zdjęcie, aby rozpocząć.", anchor="w", fg="#333", font=("Arial", 9))
        self.status_label.pack(fill=tk.X, padx=8)

        # Skróty klawiszowe
        self.root.bind("<Left>", lambda e: self.step_frame(-1))
        self.root.bind("<Right>", lambda e: self.step_frame(1))
        self.root.bind("<Shift-Left>", lambda e: self.step_frame(-10))
        self.root.bind("<Shift-Right>", lambda e: self.step_frame(10))
        self.root.bind("<Up>", lambda e: self.step_frame(30))
        self.root.bind("<Down>", lambda e: self.step_frame(-30))
        self.root.bind("<Delete>", lambda e: self.remove_last())
        self.root.focus_set()

        self.video_frame.bind("<Configure>", self.on_window_resize)
        self.update_model_indicator()

    def on_line_toggle(self):
        self.polygon_pts = []
        self.current_mouse_orig = None
        self.refresh()

    def update_model_indicator(self):
        mtype = self.face_detector.current_model_type
        mpath = os.path.basename(self.face_detector.model_path) if self.face_detector.model_path else "brak pliku"
        self.mode_label.config(text=f"DETEKTOR AI:\n{mtype}\n({mpath})", bg="#BBDEFB")

    def on_model_changed(self, event=None):
        selected = self.model_combo.get()
        success = self.face_detector.load_model(selected)
        if not success:
            ans = messagebox.askyesno(
                "Brak pliku modelu",
                f"Nie znaleziono pliku .onnx dla {selected} w folderze programu.\n\nCzy chcesz wskazać plik ręcznie?"
            )
            if ans:
                self.browse_model_file()
        self.update_model_indicator()
        if self.cap or self.is_image_mode:
            self.show_frame(self.current_idx, heavy=True, force_detect=True)

    def browse_model_file(self):
        selected = self.model_combo.get()
        fpath = filedialog.askopenfilename(
            title=f"Wskaż plik .onnx dla {selected}",
            filetypes=[("Model ONNX", "*.onnx"), ("Wszystkie pliki", "*.*")]
        )
        if fpath:
            self.face_detector.load_model(selected, custom_path=fpath)
            self.update_model_indicator()
            if self.cap or self.is_image_mode:
                self.show_frame(self.current_idx, heavy=True, force_detect=True)

    def jump_to_start(self):
        if not self.is_image_mode and self.total_frames > 0:
            self.show_frame(0, heavy=True, force_detect=True)

    def jump_to_end(self):
        if not self.is_image_mode and self.total_frames > 0:
            self.show_frame(max(0, self.total_frames - 1), heavy=True, force_detect=True)

    def on_window_resize(self, event):
        if abs(event.width - self._last_resize_w) > 5 or abs(event.height - self._last_resize_h) > 5:
            self._last_resize_w = event.width
            self._last_resize_h = event.height
            self.refresh()

    def refresh(self):
        if self.cap or self.is_image_mode:
            self.show_frame(self.current_idx, heavy=True)

    def reset_zoom(self):
        self.zoom_level = 1.0
        if self.w > 0 and self.h > 0:
            self.view_cx = self.w / 2.0
            self.view_cy = self.h / 2.0
        self.show_frame(self.current_idx, heavy=False)

    def on_mouse_wheel(self, event):
        if (not self.cap and not self.is_image_mode) or self.w == 0 or self.h == 0:
            return

        if hasattr(event, 'delta') and event.delta != 0:
            factor = 1.25 if event.delta > 0 else (1.0 / 1.25)
        elif getattr(event, 'num', None) == 4:
            factor = 1.25
        elif getattr(event, 'num', None) == 5:
            factor = 1.0 / 1.25
        else:
            return

        old_zoom = self.zoom_level
        new_zoom = max(1.0, min(12.0, self.zoom_level * factor))
        if abs(new_zoom - 1.0) < 0.05:
            new_zoom = 1.0

        if new_zoom == old_zoom:
            return

        orig = self.event_to_orig(event)
        if orig and new_zoom > 1.0:
            ox, oy = orig
            ratio = 1.0 - (old_zoom / new_zoom)
            self.view_cx += (ox - self.view_cx) * ratio
            self.view_cy += (oy - self.view_cy) * ratio
        elif new_zoom == 1.0:
            self.view_cx = self.w / 2.0
            self.view_cy = self.h / 2.0

        self.zoom_level = new_zoom
        self.show_frame(self.current_idx, heavy=False)

    def on_pan_start(self, event):
        self.pan_start_x = event.x
        self.pan_start_y = event.y
        self.pan_start_cx = self.view_cx
        self.pan_start_cy = self.view_cy
        self.is_panning = True
        self.video_label.config(cursor="fleur")

    def on_pan_drag(self, event):
        if not getattr(self, 'is_panning', False) or self.disp_scale <= 0:
            return
        dx_screen = event.x - self.pan_start_x
        dy_screen = event.y - self.pan_start_y
        
        dx_orig = dx_screen / self.disp_scale
        dy_orig = dy_screen / self.disp_scale
        
        self.view_cx = self.pan_start_cx - dx_orig
        self.view_cy = self.pan_start_cy - dy_orig
        self.show_frame(self.current_idx, heavy=False)

    def on_pan_end(self, event):
        self.is_panning = False
        self.video_label.config(cursor="")

    def on_right_down(self, event):
        if self.line_var.get() and len(self.polygon_pts) > 0:
            self.polygon_pts = []
            self.current_mouse_orig = None
            self.show_frame(self.current_idx, heavy=False)
            return

        if self.zoom_level > 1.001:
            self.is_right_panning = True
            self.right_pan_dragged = False
            self.on_pan_start(event)
        else:
            self.is_right_panning = False
            self.right_pan_dragged = False

    def on_right_drag(self, event):
        if getattr(self, 'is_right_panning', False):
            dx = abs(event.x - self.pan_start_x)
            dy = abs(event.y - self.pan_start_y)
            if dx > 3 or dy > 3:
                self.right_pan_dragged = True
                self.on_pan_drag(event)

    def on_right_up(self, event):
        if getattr(self, 'is_right_panning', False):
            self.is_right_panning = False
            self.on_pan_end(event)
            if not self.right_pan_dragged:
                self.delete_face_at_event(event)
        else:
            self.delete_face_at_event(event)

    def delete_face_at_event(self, event):
        orig = self.event_to_orig(event)
        if not orig:
            return
        cx, cy = orig
        is_circle = self.circle_var.get()
        
        for tr in list(self.trackers):
            if tr["start_frame"] <= self.current_idx <= (tr["end_frame"] if tr["end_frame"] is not None else 999999):
                bbox = tr.get("last_good_bbox") or tr.get("last_bbox") or tr["init_bbox"]
                if bbox:
                    x, y, bw, bh = bbox
                    if is_circle:
                        cx0 = x + bw / 2
                        cy0 = y + bh / 2
                        a = bw / 2
                        b = bh / 2
                        if a > 0 and b > 0 and ((cx - cx0) / a) ** 2 + ((cy - cy0) / b) ** 2 <= 1.25:
                            self.delete_by_id(tr["id"])
                            return
                    else:
                        if x <= cx <= x + bw and y <= cy <= y + bh:
                            self.delete_by_id(tr["id"])
                            return

    def to_disp(self, ox, oy):
        return int((ox - self.crop_x0) * self.disp_scale), int((oy - self.crop_y0) * self.disp_scale)

    def to_disp_dim(self, dw_val, dh_val):
        return max(1, int(dw_val * self.disp_scale)), max(1, int(dh_val * self.disp_scale))

    def on_mouse_motion(self, event):
        orig = self.event_to_orig(event)

        if self.is_mouse_down or self.active_drag_action is not None or self.is_panning:
            return

        if self.line_var.get() and len(self.polygon_pts) > 0:
            self.current_mouse_orig = orig
            self.video_label.config(cursor="crosshair")
            self.show_frame(self.current_idx, heavy=False)
            return

        if not orig or not self.trackers:
            if self.hover_action is not None:
                self.hover_action = None
                self.hover_tracker = None
                self.video_label.config(cursor="crosshair" if self.line_var.get() else "")
                self.show_frame(self.current_idx, heavy=False)
            return

        ox, oy = orig
        m = max(3, int(8 / max(0.1, self.disp_scale)))
        rc = max(6, int(15 / max(0.1, self.disp_scale)))

        found_action = None
        found_tracker = None

        for tr in reversed(self.trackers):
            if not self.is_image_mode:
                if self.current_idx < tr["start_frame"]:
                    continue
                if tr["end_frame"] is not None and self.current_idx > tr["end_frame"]:
                    continue

            bbox = tr.get("last_good_bbox") or tr.get("last_bbox") or tr.get("init_bbox")
            if not bbox:
                continue
            bx, by, bw, bh = bbox
            cx, cy = bx + bw // 2, by + bh // 2

            if (ox - cx) ** 2 + (oy - cy) ** 2 <= rc ** 2:
                found_action = 'move'
                found_tracker = tr
                break

            if abs(ox - bx) <= m and abs(oy - by) <= m:
                found_action = 'resize_tl'; found_tracker = tr; break
            if abs(ox - (bx + bw)) <= m and abs(oy - by) <= m:
                found_action = 'resize_tr'; found_tracker = tr; break
            if abs(ox - bx) <= m and abs(oy - (by + bh)) <= m:
                found_action = 'resize_bl'; found_tracker = tr; break
            if abs(ox - (bx + bw)) <= m and abs(oy - (by + bh)) <= m:
                found_action = 'resize_br'; found_tracker = tr; break

            if abs(ox - bx) <= m and (by - m <= oy <= by + bh + m):
                found_action = 'resize_l'; found_tracker = tr; break
            if abs(ox - (bx + bw)) <= m and (by - m <= oy <= by + bh + m):
                found_action = 'resize_r'; found_tracker = tr; break
            if abs(oy - by) <= m and (bx - m <= ox <= bx + bw + m):
                found_action = 'resize_t'; found_tracker = tr; break
            if abs(oy - (by + bh)) <= m and (bx - m <= ox <= bx + bw + m):
                found_action = 'resize_b'; found_tracker = tr; break

        cursor_map = {
            'move': 'fleur',
            'resize_l': 'sb_h_double_arrow',
            'resize_r': 'sb_h_double_arrow',
            'resize_t': 'sb_v_double_arrow',
            'resize_b': 'sb_v_double_arrow',
            'resize_tl': 'size_nw_se',
            'resize_br': 'size_nw_se',
            'resize_tr': 'size_ne_sw',
            'resize_bl': 'size_ne_sw',
        }

        prev_action = self.hover_action
        self.hover_action = found_action
        self.hover_tracker = found_tracker

        if found_action:
            self.video_label.config(cursor=cursor_map.get(found_action, 'fleur'))
        else:
            self.video_label.config(cursor="crosshair" if self.line_var.get() else "")

        if prev_action != found_action:
            self.show_frame(self.current_idx, heavy=False)

    def on_mouse_double_click(self, event):
        if not self.line_var.get():
            return

        if len(self.polygon_pts) >= 2:
            p1 = self.polygon_pts[-1]
            p2 = self.polygon_pts[-2]
            if abs(p1[0] - p2[0]) < 12 and abs(p1[1] - p2[1]) < 12:
                self.polygon_pts.pop()

        if len(self.polygon_pts) >= 3:
            pts_arr = np.array(self.polygon_pts, dtype=np.int32)
            bx, by, bw, bh = cv2.boundingRect(pts_arr)
            if bw >= 5 and bh >= 5:
                rel_poly = [(int(p[0] - bx), int(p[1] - by)) for p in self.polygon_pts]
                self._add_or_update_tracker((bx, by, bw, bh), mode_type="line", rel_poly=rel_poly)
                print(f"[LINE] Utworzono zaznaczenie wielokątem: {len(self.polygon_pts)} punktów")

        self.polygon_pts = []
        self.current_mouse_orig = None
        self.show_frame(self.current_idx, heavy=True)
        return "break"

    def on_mouse_down(self, event):
        if event.state & 0x0001:
            self.is_shift_panning = True
            self.on_pan_start(event)
            return

        orig = self.event_to_orig(event)
        if not orig:
            return

        # PRIORYTET 1: Kontrolki edycji (Move/Resize) mają pierwszeństwo przed rysowaniem punktów
        if len(self.polygon_pts) == 0 and self.hover_action and self.hover_tracker:
            self.active_drag_action = self.hover_action
            self.active_drag_tracker = self.hover_tracker
            self.drag_start_event_x = orig[0]
            self.drag_start_event_y = orig[1]
            self.drag_start_bbox = self.hover_tracker.get("last_good_bbox") or self.hover_tracker.get("last_bbox") or self.hover_tracker["init_bbox"]
            if self.hover_tracker.get("rel_poly"):
                self.drag_start_rel_poly = list(self.hover_tracker["rel_poly"])
            else:
                self.drag_start_rel_poly = None
            return

        # PRIORYTET 2: Rysowanie punktów wielokąta w trybie LINE
        if self.line_var.get():
            self.polygon_pts.append(orig)
            self.current_mouse_orig = orig
            self.show_frame(self.current_idx, heavy=False)
            return

        # PRIORYTET 3: Standardowe zaznaczanie
        self.is_mouse_down = True
        self.has_dragged = False
        self.draw_start = orig
        self.draw_rect = None

    def on_mouse_drag(self, event):
        if getattr(self, 'is_shift_panning', False):
            self.on_pan_drag(event)
            return

        orig = self.event_to_orig(event)
        if not orig:
            return

        # Obsługa przesuwania lub zmiany rozmiaru ramki
        if self.active_drag_action and self.active_drag_tracker and self.drag_start_bbox:
            dx = orig[0] - self.drag_start_event_x
            dy = orig[1] - self.drag_start_event_y
            bx, by, bw, bh = self.drag_start_bbox

            new_x, new_y, new_w, new_h = bx, by, bw, bh

            if self.active_drag_action == 'move':
                new_x = max(0, min(self.w - bw, bx + dx))
                new_y = max(0, min(self.h - bh, by + dy))
            elif self.active_drag_action == 'resize_r':
                new_w = max(10, min(self.w - bx, bw + dx))
            elif self.active_drag_action == 'resize_b':
                new_h = max(10, min(self.h - by, bh + dy))
            elif self.active_drag_action == 'resize_l':
                new_x = max(0, min(bx + bw - 10, bx + dx))
                new_w = (bx + bw) - new_x
            elif self.active_drag_action == 'resize_t':
                new_y = max(0, min(by + bh - 10, by + dy))
                new_h = (by + bh) - new_y
            elif self.active_drag_action == 'resize_br':
                new_w = max(10, min(self.w - bx, bw + dx))
                new_h = max(10, min(self.h - by, bh + dy))
            elif self.active_drag_action == 'resize_tl':
                new_x = max(0, min(bx + bw - 10, bx + dx))
                new_w = (bx + bw) - new_x
                new_y = max(0, min(by + bh - 10, by + dy))
                new_h = (by + bh) - new_y
            elif self.active_drag_action == 'resize_tr':
                new_w = max(10, min(self.w - bx, bw + dx))
                new_y = max(0, min(by + bh - 10, by + dy))
                new_h = (by + bh) - new_y
            elif self.active_drag_action == 'resize_bl':
                new_x = max(0, min(bx + bw - 10, bx + dx))
                new_w = (bx + bw) - new_x
                new_h = max(10, min(self.h - by, bh + dy))

            new_box = (int(new_x), int(new_y), int(new_w), int(new_h))
            
            if self.drag_start_rel_poly:
                sx = new_w / max(1, bw)
                sy = new_h / max(1, bh)
                self.active_drag_tracker["rel_poly"] = [(int(rx * sx), int(ry * sy)) for rx, ry in self.drag_start_rel_poly]

            self.active_drag_tracker["init_bbox"] = new_box
            self.active_drag_tracker["last_bbox"] = new_box
            self.active_drag_tracker["last_good_bbox"] = new_box
            if "traj" not in self.active_drag_tracker:
                self.active_drag_tracker["traj"] = {}
            self.active_drag_tracker["traj"][self.current_idx] = new_box

            self.show_frame(self.current_idx, heavy=False)
            return

        if self.line_var.get():
            return

        if not self.is_mouse_down or not self.draw_start:
            return
        
        dx = abs(orig[0] - self.draw_start[0])
        dy = abs(orig[1] - self.draw_start[1])
        if dx > 6 or dy > 6:
            self.has_dragged = True
            self.draw_rect = (self.draw_start[0], self.draw_start[1], orig[0], orig[1])
            self.show_frame(self.current_idx, heavy=False)

    def on_mouse_up(self, event):
        if getattr(self, 'is_shift_panning', False):
            self.is_shift_panning = False
            self.on_pan_end(event)
            return

        if self.active_drag_action and self.active_drag_tracker:
            box = self.active_drag_tracker.get("last_good_bbox")
            if box:
                if self.is_image_mode:
                    self.active_drag_tracker["init_bbox"] = box
                    self.active_drag_tracker["last_good_bbox"] = box
                    self.active_drag_tracker["last_bbox"] = box
                    self.active_drag_tracker["traj"] = {0: box}
                else:
                    target_tr = self.active_drag_tracker
                    if self.current_idx == target_tr["start_frame"]:
                        target_tr["init_bbox"] = box
                        target_tr["last_good_bbox"] = box
                        target_tr["last_bbox"] = box
                        target_tr["traj"] = {self.current_idx: box}
                        frame0 = self.get_frame_cached(self.current_idx)
                        target_tr["preview_tracker"] = self.create_tracker(frame0, box)
                        target_tr["last_idx"] = self.current_idx
                    else:
                        target_tr["end_frame"] = self.current_idx - 1
                        target_tr["preview_tracker"] = None
                        if "traj" in target_tr:
                            target_tr["traj"] = {k: v for k, v in target_tr["traj"].items() if k < self.current_idx}
                        frame0 = self.get_frame_cached(self.current_idx)
                        new_track = {
                            "id": self.next_id,
                            "face_id": target_tr["face_id"],
                            "type": target_tr["type"],
                            "start_frame": self.current_idx,
                            "init_bbox": box,
                            "rel_poly": target_tr.get("rel_poly"),
                            "preview_tracker": self.create_tracker(frame0, box),
                            "last_idx": self.current_idx,
                            "last_bbox": box,
                            "last_good_bbox": box,
                            "lost_count": 0,
                            "end_frame": None,
                            "failed": False,
                            "traj": {self.current_idx: box}
                        }
                        self.trackers.append(new_track)
                        self.next_id += 1

            self.active_drag_action = None
            self.active_drag_tracker = None
            self.drag_start_rel_poly = None
            self.show_frame(self.current_idx, heavy=True)
            self.update_list()
            return

        if self.line_var.get():
            return

        if not self.is_mouse_down:
            return
        self.is_mouse_down = False
        rect = self.draw_rect
        dragged = self.has_dragged
        self.draw_rect = None
        self.has_dragged = False

        if dragged and rect:
            x1, y1, x2, y2 = rect
            x, y = min(x1, x2), min(y1, y2)
            bw, bh = abs(x2 - x1), abs(y2 - y1)
            x, y = max(0, min(x, self.w - 10)), max(0, min(y, self.h - 10))
            bw, bh = min(bw, self.w - x), min(bh, self.h - y)
            if bw >= 8 and bh >= 8:
                self._add_or_update_tracker((x, y, bw, bh), mode_type="manual")
            else:
                self.show_frame(self.current_idx, heavy=False)
        else:
            orig = self.event_to_orig(event)
            if not orig:
                return
            cx, cy = orig
            
            if len(self.faces_current) == 0:
                cur = self.get_frame_cached(self.current_idx)
                if cur is not None:
                    self.faces_current = self.face_detector.detect(cur)

            found = None
            for (x, y, bw, bh) in self.faces_current:
                if (x - 15) < cx < (x + bw + 15) and (y - 15) < cy < (y + bh + 15):
                    found = (x, y, bw, bh)
                    break

            if found:
                self._add_or_update_tracker(found, mode_type="auto")
            else:
                self.info_label.config(text=f"Klik ({cx},{cy}) poza zieloną ramką.\nKliknij w zieloną ramkę lub przeciągnij myszą własną ramkę.")

    def choose_file(self):
        path = filedialog.askopenfilename(filetypes=[("Wideo", "*.mp4 *.mov *.avi *.mkv *.wmv")])
        if not path:
            return
        self.input_path = path
        if self.cap:
            self.cap.release()
        self.cap = cv2.VideoCapture(path)
        if not self.cap.isOpened():
            messagebox.showerror("Błąd", "Nie można otworzyć wskazanego pliku wideo.")
            return

        self.is_image_mode = False
        self.total_frames = int(self.cap.get(cv2.CAP_PROP_FRAME_COUNT))
        self.fps = self.cap.get(cv2.CAP_PROP_FPS) or 25
        self.w = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self.h = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        
        self.trackers = []
        self.next_id = 1
        self.next_face_id = 1
        self.is_tracking_paused = False
        self.polygon_pts = []
        self.frame_cache.clear()

        self.reset_zoom()
        self._update_pause_ui()

        max_val = max(0, self.total_frames - 1)
        self.slider.config(to=max_val, state="normal")
        self.total_label.config(text=f"/ {max_val}")
        self.btn_first.config(state="normal")
        self.btn_last.config(state="normal")
        self.btn_pause.config(state="normal")
        self.btn_resume.config(state="normal")
        self.frame_entry.config(state="normal")

        self.show_frame(0, heavy=True, force_detect=True)
        self.update_list()
        self.root.focus_set()
        self.info_label.config(text=f"Wideo: {os.path.basename(path)}\nRozmiar: {self.w}x{self.h}\nKlatek: {self.total_frames} ({self.fps:.1f} FPS)")

    def choose_image(self):
        path = filedialog.askopenfilename(filetypes=[("Zdjęcia", "*.jpg *.jpeg *.png *.bmp *.webp")])
        if not path:
            return
        
        img = None
        try:
            img = cv2.imdecode(np.fromfile(path, dtype=np.uint8), cv2.IMREAD_COLOR)
        except Exception:
            img = cv2.imread(path)
            
        if img is None:
            messagebox.showerror("Błąd", "Nie można otworzyć wskazanego pliku graficznego.")
            return

        if self.cap:
            self.cap.release()
            self.cap = None

        self.input_path = path
        self.is_image_mode = True
        self.h, self.w = img.shape[:2]
        self.total_frames = 1
        self.fps = 1
        self.current_idx = 0
        
        self.trackers = []
        self.next_id = 1
        self.next_face_id = 1
        self.is_tracking_paused = False
        self.polygon_pts = []
        self.frame_cache = {0: img.copy()}
        self.orig_frame_cache = img.copy()

        self.reset_zoom()
        self._update_pause_ui()

        self.slider.config(to=0, state="disabled")
        self.total_label.config(text="/ 0 (Zdjęcie)")
        self.btn_first.config(state="disabled")
        self.btn_last.config(state="disabled")
        self.btn_pause.config(state="disabled")
        self.btn_resume.config(state="disabled")
        self.frame_entry.config(state="disabled")

        self.show_frame(0, heavy=True, force_detect=True)
        self.update_list()
        self.root.focus_set()
        self.info_label.config(text=f"Zdjęcie: {os.path.basename(path)}\nRozmiar: {self.w}x{self.h} px")

    def _update_pause_ui(self):
        if self.is_tracking_paused:
            self.pause_indicator.config(text="⏸ PAUZA ŚLEDZENIA", fg="#F44336")
        else:
            self.pause_indicator.config(text="● ŚLEDZENIE AKTYWNE", fg="#4CAF50")

    def pause_tracking(self):
        if self.is_image_mode or not self.trackers:
            return
        
        paused_cnt = 0
        for tr in self.trackers:
            if tr["start_frame"] <= self.current_idx and (tr["end_frame"] is None or tr["end_frame"] >= self.current_idx):
                tr["end_frame"] = max(tr["start_frame"], self.current_idx - 1)
                tr["preview_tracker"] = None
                paused_cnt += 1

        self.is_tracking_paused = True
        self._update_pause_ui()
        print(f"[PAUSE] Wstrzymano {paused_cnt} twarzy na klatce {self.current_idx}")
        self.show_frame(self.current_idx, heavy=True)
        self.update_list()

    def resume_tracking(self):
        if self.is_image_mode or not self.trackers:
            return

        resumed_cnt = 0
        faces_to_resume = {}
        for tr in reversed(self.trackers):
            fid = tr["face_id"]
            if fid not in faces_to_resume and tr.get("end_frame") is not None:
                faces_to_resume[fid] = tr

        for fid, tr in faces_to_resume.items():
            bbox = tr.get("last_good_bbox") or tr.get("last_bbox") or tr["init_bbox"]
            self._add_or_update_tracker(bbox, mode_type=tr["type"], force_new_face=False, rel_poly=tr.get("rel_poly"))
            resumed_cnt += 1

        if resumed_cnt > 0:
            print(f"[RESUME] Wznowiono {resumed_cnt} twarzy na klatce {self.current_idx}")

    def get_frame_cached(self, idx):
        if idx in self.frame_cache:
            return self.frame_cache[idx]
        if not self.cap:
            return None
        self.cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
        ret, frame = self.cap.read()
        if not ret:
            return None
        if len(self.frame_cache) >= self.cache_size:
            oldest = next(iter(self.frame_cache))
            del self.frame_cache[oldest]
        self.frame_cache[idx] = frame.copy()
        return frame

    def create_tracker(self, frame, bbox):
        if frame is None or bbox[2] <= 0 or bbox[3] <= 0:
            return None
        try:
            tr = cv2.legacy.TrackerCSRT_create()
        except Exception:
            try:
                tr = cv2.TrackerCSRT_create()
            except Exception:
                return None
        try:
            ok = tr.init(frame, bbox)
            return tr if ok else None
        except Exception as e:
            print(f"tracker init fail {e}")
            return None

    def event_to_orig(self, event):
        try:
            if self.disp_scale <= 0 or self.disp_w <= 0 or self.disp_h <= 0 or self.w == 0 or self.h == 0:
                return None

            ix = event.x - self.disp_off_x
            iy = event.y - self.disp_off_y
            if ix < 0 or iy < 0 or ix > self.disp_w or iy > self.disp_h:
                return None

            cx_crop = ix / self.disp_scale
            cy_crop = iy / self.disp_scale

            ox = int(self.crop_x0 + cx_crop)
            oy = int(self.crop_y0 + cy_crop)
            return (max(0, min(ox, self.w - 1)), max(0, min(oy, self.h - 1)))
        except Exception as e:
            print(f"event_to_orig err {e}")
            return None

    def ensure_tracker(self, tr, target_idx, heavy=False):
        if self.is_image_mode:
            return tr.get("last_good_bbox") or tr.get("last_bbox") or tr.get("init_bbox")

        if target_idx < tr["start_frame"]:
            return None
        if tr.get("end_frame") is not None and target_idx > tr["end_frame"]:
            return None

        if "traj" not in tr:
            tr["traj"] = {tr["start_frame"]: tr["init_bbox"]}

        if target_idx in tr["traj"]:
            return tr["traj"][target_idx]

        if not heavy and target_idx > tr["last_idx"] and (target_idx - tr["last_idx"]) > 3:
            return tr.get("last_good_bbox") or tr["last_bbox"]

        max_jump = self.jump_slider.get()

        if target_idx > tr["last_idx"]:
            if tr.get("failed", False):
                return None if self.stop_on_loss_var.get() else tr.get("last_good_bbox")

            if tr.get("preview_tracker") is None:
                start_f = self.get_frame_cached(tr["last_idx"])
                if start_f is not None:
                    tr["preview_tracker"] = self.create_tracker(start_f, tr["last_good_bbox"])

            if tr.get("preview_tracker") is None:
                return tr.get("last_good_bbox") or tr["last_bbox"]

            for fi in range(tr["last_idx"] + 1, target_idx + 1):
                frm = self.get_frame_cached(fi)
                if frm is None:
                    break
                ok, box = tr["preview_tracker"].update(frm)
                if ok:
                    x, y, bw, bh = map(int, box)
                    px, py, pbw, pbh = tr.get("last_good_bbox", tr["last_bbox"])
                    dist = ((x + bw / 2 - (px + pbw / 2)) ** 2 + (y + bh / 2 - (py + pbh / 2)) ** 2) ** 0.5
                    ratio = max(bw / max(1, pbw), pbw / max(1, bw), bh / max(1, pbh), pbh / max(1, bh)) if pbw > 0 and pbh > 0 else 1
                    
                    if dist > max_jump or ratio > 2.8:
                        tr["lost_count"] += 1
                        if tr["lost_count"] > 2:
                            tr["failed"] = True
                            break
                        continue

                    cur_box = (x, y, bw, bh)
                    tr["last_bbox"] = cur_box
                    tr["last_good_bbox"] = cur_box
                    tr["last_idx"] = fi
                    tr["lost_count"] = 0
                    tr["traj"][fi] = cur_box
                else:
                    tr["lost_count"] += 1
                    if tr["lost_count"] > 3 and self.stop_on_loss_var.get():
                        tr["failed"] = True
                        break

            if tr.get("failed", False) and self.stop_on_loss_var.get():
                return None
            return tr["traj"].get(target_idx, tr.get("last_good_bbox"))

        start_fi = max([k for k in tr["traj"].keys() if k <= target_idx], default=tr["start_frame"])
        box_at_start = tr["traj"][start_fi]
        frm_start = self.get_frame_cached(start_fi)
        if frm_start is not None:
            t = self.create_tracker(frm_start, box_at_start)
            if t is not None:
                tr["preview_tracker"] = t
                for fi in range(start_fi + 1, target_idx + 1):
                    frm = self.get_frame_cached(fi)
                    if frm is None: break
                    ok, box = tr["preview_tracker"].update(frm)
                    if ok:
                        c_box = tuple(map(int, box))
                        tr["traj"][fi] = c_box
                        tr["last_idx"] = fi
                        tr["last_good_bbox"] = c_box
        return tr["traj"].get(target_idx, tr.get("last_good_bbox"))

    def _compute_iou(self, b1, b2):
        x1, y1, w1, h1 = b1
        x2, y2, w2, h2 = b2
        xi1 = max(x1, x2)
        yi1 = max(y1, y2)
        xi2 = min(x1 + w1, x2 + w2)
        yi2 = min(y1 + h1, y2 + h2)
        inter_w = max(0, xi2 - xi1)
        inter_h = max(0, yi2 - yi1)
        inter = inter_w * inter_h
        union = w1 * h1 + w2 * h2 - inter
        return inter / union if union > 0 else 0

    def _add_or_update_tracker(self, new_bbox, mode_type="auto", force_new_face=False, rel_poly=None):
        frame0 = self.orig_frame_cache if self.orig_frame_cache is not None else self.get_frame_cached(self.current_idx)
        if frame0 is None:
            return

        tr = self.create_tracker(frame0, new_bbox) if not self.is_image_mode else None

        matched_tracker = None
        if not force_new_face:
            for active_tr in self.trackers:
                if active_tr["start_frame"] <= self.current_idx and (active_tr["end_frame"] is None or active_tr["end_frame"] >= self.current_idx):
                    old_box = active_tr.get("last_good_bbox") or active_tr.get("last_bbox") or active_tr["init_bbox"]
                    iou = self._compute_iou(new_bbox, old_box)
                    
                    c1 = (new_bbox[0] + new_bbox[2]/2, new_bbox[1] + new_bbox[3]/2)
                    c2 = (old_box[0] + old_box[2]/2, old_box[1] + old_box[2]/2)
                    dist = ((c1[0] - c2[0])**2 + (c1[1] - c2[1])**2)**0.5
                    diag = (new_bbox[2] + new_bbox[3] + old_box[2] + old_box[3]) / 4

                    if iou > 0.20 or dist < diag * 0.75:
                        matched_tracker = active_tr
                        break

        if matched_tracker is not None:
            face_id = matched_tracker["face_id"]
            if not self.is_image_mode:
                self.trackers = [t for t in self.trackers if not (t["face_id"] == face_id and t["start_frame"] >= self.current_idx)]
                matched_tracker["end_frame"] = max(matched_tracker["start_frame"], self.current_idx - 1)
                matched_tracker["preview_tracker"] = None
                if "traj" in matched_tracker:
                    matched_tracker["traj"] = {k: v for k, v in matched_tracker["traj"].items() if k < self.current_idx}
            else:
                self.trackers = [t for t in self.trackers if t["id"] != matched_tracker["id"]]
            print(f"[HANDOVER] Twarz {face_id} zaktualizowana")
        else:
            face_id = self.next_face_id
            self.next_face_id += 1
            print(f"[NEW FACE] Dodano nową twarz: Twarz {face_id}")

        new_track = {
            "id": self.next_id,
            "face_id": face_id,
            "type": mode_type,
            "start_frame": self.current_idx,
            "init_bbox": new_bbox,
            "rel_poly": rel_poly,
            "preview_tracker": tr,
            "last_idx": self.current_idx,
            "last_bbox": new_bbox,
            "last_good_bbox": new_bbox,
            "lost_count": 0,
            "end_frame": None,
            "failed": False,
            "traj": {self.current_idx: new_bbox}
        }
        self.trackers.append(new_track)
        self.next_id += 1

        self.is_tracking_paused = False
        self._update_pause_ui()

        self.show_frame(self.current_idx, heavy=True)
        self.update_list()

    def add_all_detected_faces(self):
        if not self.faces_current:
            cur = self.get_frame_cached(self.current_idx)
            if cur is not None:
                self.faces_current = self.face_detector.detect(cur)
        if not self.faces_current:
            messagebox.showinfo("Brak danych", "Detektor nie wykrył zielonych ramek twarzy.")
            return

        added = 0
        for box in self.faces_current:
            self._add_or_update_tracker(box, mode_type="auto")
            added += 1

        self.show_frame(self.current_idx, heavy=True)
        self.update_list()

    def remove_last(self):
        if not self.trackers:
            return
        removed = self.trackers.pop()
        fid = removed["face_id"]
        
        same_face = [t for t in self.trackers if t["face_id"] == fid]
        if same_face:
            same_face[-1]["end_frame"] = None
        
        self.next_id = max([t["id"] for t in self.trackers], default=0) + 1
        self.show_frame(self.current_idx, heavy=True)
        self.update_list()

    def clear_trackers(self):
        self.trackers = []
        self.polygon_pts = []
        self.current_mouse_orig = None
        self.next_id = 1
        self.next_face_id = 1
        self.is_tracking_paused = False
        self._update_pause_ui()
        self.show_frame(self.current_idx, heavy=True)
        self.update_list()

    def delete_by_id(self, tid):
        target = next((t for t in self.trackers if t["id"] == tid), None)
        if target:
            fid = target["face_id"]
            self.trackers = [t for t in self.trackers if t["id"] != tid]
            same_face = [t for t in self.trackers if t["face_id"] == fid]
            if same_face and same_face[-1]["end_frame"] is not None:
                same_face[-1]["end_frame"] = None
        self.next_id = max([t["id"] for t in self.trackers], default=0) + 1
        self.show_frame(self.current_idx, heavy=True)
        self.update_list()

    def update_list(self):
        for w in self.tracker_list_frame.winfo_children():
            w.destroy()
        
        for tr in self.trackers:
            is_active = (tr["end_frame"] is None) or (tr["start_frame"] <= self.current_idx <= tr["end_frame"])
            col = "#C8E6C9" if is_active else "#EEEEEE"
            
            f = tk.Frame(self.tracker_list_frame, bg=col, bd=1, relief=tk.RAISED)
            f.pack(fill=tk.X, pady=2, padx=2)
            
            end_str = "..." if tr["end_frame"] is None else str(tr["end_frame"])
            txt = f"Twarz {tr['face_id']} [ID{tr['id']}] ({tr['type'][0].upper()})"
            if not self.is_image_mode:
                txt += f" [{tr['start_frame']}-{end_str}]"
            
            tk.Label(f, text=txt, bg=col, font=("Arial", 8, "bold" if is_active else "normal")).pack(side=tk.LEFT, padx=3)
            
            tid = tr["id"]
            tk.Button(f, text="X", bg="#f44336", fg="white", font=("Arial", 7, "bold"), command=lambda t=tid: self.delete_by_id(t)).pack(side=tk.RIGHT, padx=2)
            if not self.is_image_mode:
                tk.Button(f, text="IDŹ", bg="#4CAF50", fg="white", font=("Arial", 7), command=lambda st=tr["start_frame"]: self.show_frame(st, heavy=True, force_detect=True)).pack(side=tk.RIGHT, padx=2)

    def _apply_blur_or_pixel(self, roi, k_blur, is_pixel):
        rh, rw = roi.shape[:2]
        if rh <= 0 or rw <= 0:
            return roi
        if is_pixel:
            block_size = max(4, int(k_blur / 3.5))
            pw = max(1, rw // block_size)
            ph = max(1, rh // block_size)
            small = cv2.resize(roi, (pw, ph), interpolation=cv2.INTER_LINEAR)
            return cv2.resize(small, (rw, rh), interpolation=cv2.INTER_NEAREST)
        else:
            if k_blur % 2 == 0:
                k_blur += 1
            k_blur = max(15, min(k_blur, 151))
            return cv2.GaussianBlur(roi, (k_blur, k_blur), 30)

    def show_frame(self, idx, heavy=False, force_detect=False):
        frame = self.get_frame_cached(idx)
        if frame is None:
            return
        self.orig_frame_cache = frame.copy()
        self.current_idx = idx

        if force_detect or (heavy and (idx % 6 == 0 or len(self.faces_current) == 0)):
            self.faces_current = self.face_detector.detect(frame)
        elif not heavy and len(self.faces_current) == 0:
            self.faces_current = self.face_detector.detect(frame)

        vis = frame.copy()

        is_bb = self.blackbox_var.get()
        is_circle = self.circle_var.get()
        is_pixel = self.pixel_mode_var.get()
        k_val = int(self.blur_slider.get())

        active_trackers_count = 0

        # Rysowanie zamazań bez obwódek
        for tr in self.trackers:
            if not self.is_image_mode:
                if idx < tr["start_frame"]:
                    continue
                if tr["end_frame"] is not None and idx > tr["end_frame"]:
                    continue

            bbox = self.ensure_tracker(tr, idx, heavy=heavy)
            if bbox is None:
                continue
            
            active_trackers_count += 1
            x, y, bw, bh = bbox
            if bw < 5 or bh < 5:
                continue

            x1, y1 = max(0, x), max(0, y)
            x2, y2 = min(self.w, x + bw), min(self.h, y + bh)
            roi = vis[y1:y2, x1:x2]

            cx = x + bw // 2
            cy = y + bh // 2
            ax_w = bw // 2
            ax_h = bh // 2

            # Tryb WIELOKĄTA (LINE)
            if tr.get("rel_poly"):
                init_w = max(1, tr["init_bbox"][2])
                init_h = max(1, tr["init_bbox"][3])
                sx = bw / init_w
                sy = bh / init_h
                cur_poly = np.array([[int(x + rx * sx), int(y + ry * sy)] for rx, ry in tr["rel_poly"]], dtype=np.int32)
                roi_poly = cur_poly - np.array([x1, y1])

                mask = np.zeros(roi.shape[:2], dtype=np.uint8)
                cv2.fillPoly(mask, [roi_poly], 255)

                if is_bb:
                    vis[y1:y2, x1:x2] = np.where(mask[:, :, None] == 255, 0, roi)
                else:
                    if roi.size > 0:
                        processed_roi = self._apply_blur_or_pixel(roi, k_val, is_pixel)
                        vis[y1:y2, x1:x2] = np.where(mask[:, :, None] == 255, processed_roi, roi)

            # Tryb standardowy (Prostokąt / Owal)
            else:
                if is_bb:
                    if is_circle:
                        cv2.ellipse(vis, (cx, cy), (ax_w, ax_h), 0, 0, 360, (0, 0, 0), -1)
                    else:
                        cv2.rectangle(vis, (x1, y1), (x2, y2), (0, 0, 0), -1)
                else:
                    if roi.size > 0:
                        processed_roi = self._apply_blur_or_pixel(roi, k_val, is_pixel)
                        if is_circle:
                            mask = np.zeros(roi.shape[:2], dtype=np.uint8)
                            c_roi = ((x2 - x1) // 2, (y2 - y1) // 2)
                            cv2.ellipse(mask, c_roi, (ax_w, ax_h), 0, 0, 360, 255, -1)
                            vis[y1:y2, x1:x2] = np.where(mask[:, :, None] == 255, processed_roi, roi)
                        else:
                            vis[y1:y2, x1:x2] = processed_roi

        # --- WYCINANIE OBSZARU ZOOM I PAN ---
        h, w = vis.shape[:2]
        if self.zoom_level > 1.001 and w > 0 and h > 0:
            w_vis = w / self.zoom_level
            h_vis = h / self.zoom_level
            x0 = max(0.0, min(self.view_cx - w_vis / 2.0, w - w_vis))
            y0 = max(0.0, min(self.view_cy - h_vis / 2.0, h - h_vis))
            self.view_cx = x0 + w_vis / 2.0
            self.view_cy = y0 + h_vis / 2.0
            
            self.crop_x0 = int(x0)
            self.crop_y0 = int(y0)
            self.crop_w = max(1, int(w_vis))
            self.crop_h = max(1, int(h_vis))
            
            cropped = vis[self.crop_y0:self.crop_y0 + self.crop_h, self.crop_x0:self.crop_x0 + self.crop_w]
        else:
            self.zoom_level = 1.0
            self.crop_x0 = 0
            self.crop_y0 = 0
            self.crop_w = w
            self.crop_h = h
            self.view_cx = w / 2.0
            self.view_cy = h / 2.0
            cropped = vis

        lw = self.video_label.winfo_width()
        lh = self.video_label.winfo_height()
        if lw < 50 or lh < 50:
            lw = max(100, self.root.winfo_width() - 350)
            lh = max(100, self.root.winfo_height() - 250)

        ch, cw = cropped.shape[:2]
        sw = lw / cw if cw > 0 else 1.0
        sh = lh / ch if ch > 0 else 1.0
        scale = min(sw, sh) * 0.98
        scale = max(scale, 0.05)
        self.disp_scale = scale
        
        dw = int(cw * scale)
        dh = int(ch * scale)
        self.disp_w = dw
        self.disp_h = dh
        self.disp_off_x = max(0, (lw - dw) // 2)
        self.disp_off_y = max(0, (lh - dh) // 2)

        if scale != 1.0 and dw > 0 and dh > 0:
            vis_display = cv2.resize(cropped, (dw, dh), interpolation=cv2.INTER_AREA if scale < 1.0 else cv2.INTER_LINEAR)
        else:
            vis_display = cropped.copy()

        # --- RYSOWANIE KONTROLEK BEZPOŚREDNIO NA VIS_DISPLAY ---
        # 1. Zielone ramki AI
        for (gx, gy, gbw, gbh) in self.faces_current:
            dsx, dsy = self.to_disp(gx, gy)
            dsw, dsh = self.to_disp_dim(gbw, gbh)
            cv2.rectangle(vis_display, (dsx, dsy), (dsx + dsw, dsy + dsh), (0, 255, 0), 2)

        # 2. Uchwyty przesuwania i skalowania ramki
        target_tr = self.active_drag_tracker if self.active_drag_tracker else (self.hover_tracker if self.hover_action else None)
        if target_tr:
            bbox = target_tr.get("last_good_bbox") or target_tr.get("last_bbox") or target_tr["init_bbox"]
            if bbox:
                bx, by, bw, bh = bbox
                dsx, dsy = self.to_disp(bx, by)
                dsw, dsh = self.to_disp_dim(bw, bh)
                dscx = dsx + dsw // 2
                dscy = dsy + dsh // 2

                # Cienka ramka pomocnicza o stałej grubości
                if target_tr.get("rel_poly"):
                    init_w = max(1, target_tr["init_bbox"][2])
                    init_h = max(1, target_tr["init_bbox"][3])
                    poly_disp = []
                    for rx, ry in target_tr["rel_poly"]:
                        ox = bx + rx * (bw / init_w)
                        oy = by + ry * (bh / init_h)
                        poly_disp.append(self.to_disp(ox, oy))
                    cv2.polylines(vis_display, [np.array(poly_disp, dtype=np.int32)], isClosed=True, color=(0, 255, 255), thickness=1, lineType=cv2.LINE_AA)
                elif is_circle:
                    cv2.ellipse(vis_display, (dscx, dscy), (dsw // 2, dsh // 2), 0, 0, 360, (0, 255, 255), 1, cv2.LINE_AA)
                else:
                    cv2.rectangle(vis_display, (dsx, dsy), (dsx + dsw, dsy + dsh), (0, 255, 255), 1, cv2.LINE_AA)

                # Niezmienna, poręczna ikona przesuwania (promień 11 px)
                ir = min(11, max(6, min(dsw, dsh) // 3))
                cv2.circle(vis_display, (dscx, dscy), ir + 2, (0, 0, 0), -1, cv2.LINE_AA)
                cv2.circle(vis_display, (dscx, dscy), ir + 2, (0, 255, 255), 1, cv2.LINE_AA)
                arr_len = ir - 2
                if arr_len >= 3:
                    cv2.line(vis_display, (dscx - arr_len, dscy), (dscx + arr_len, dscy), (0, 255, 255), 1, cv2.LINE_AA)
                    cv2.line(vis_display, (dscx, dscy - arr_len), (dscx, dscy + arr_len), (0, 255, 255), 1, cv2.LINE_AA)

                # Narożniki o stałym rozmiarze 6x6 pikseli na ekranie
                h_half = 3
                corners = [
                    (dsx, dsy),
                    (dsx + dsw, dsy),
                    (dsx, dsy + dsh),
                    (dsx + dsw, dsy + dsh)
                ]
                for cx_pt, cy_pt in corners:
                    cv2.rectangle(vis_display, (cx_pt - h_half, cy_pt - h_half), (cx_pt + h_half, cy_pt + h_half), (0, 255, 255), -1)
                    cv2.rectangle(vis_display, (cx_pt - h_half, cy_pt - h_half), (cx_pt + h_half, cy_pt + h_half), (0, 0, 0), 1)

        # 3. Podgląd rysowania wielokątem (LINE)
        if self.line_var.get() and len(self.polygon_pts) > 0:
            disp_pts = [self.to_disp(pt[0], pt[1]) for pt in self.polygon_pts]
            cv2.polylines(vis_display, [np.array(disp_pts, dtype=np.int32)], isClosed=False, color=(0, 255, 255), thickness=2, lineType=cv2.LINE_AA)
            for (px, py) in disp_pts:
                cv2.circle(vis_display, (px, py), 4, (0, 165, 255), -1, cv2.LINE_AA)
            
            if self.current_mouse_orig:
                mx, my = self.to_disp(self.current_mouse_orig[0], self.current_mouse_orig[1])
                last_pt = disp_pts[-1]
                first_pt = disp_pts[0]
                cv2.line(vis_display, last_pt, (mx, my), (0, 255, 255), 1, cv2.LINE_AA)
                cv2.line(vis_display, (mx, my), first_pt, (0, 140, 255), 1, cv2.LINE_AA)
            elif len(disp_pts) >= 2:
                cv2.line(vis_display, disp_pts[-1], disp_pts[0], (0, 140, 255), 1, cv2.LINE_AA)

        # 4. Ramka rysowana ręcznie (Prostokąt / Owal)
        if self.draw_rect and not self.line_var.get():
            x1, y1, x2, y2 = self.draw_rect
            dsx1, dsy1 = self.to_disp(min(x1, x2), min(y1, y2))
            dsx2, dsy2 = self.to_disp(max(x1, x2), max(y1, y2))
            dsw = dsx2 - dsx1
            dsh = dsy2 - dsy1
            if dsw > 0 and dsh > 0:
                if is_circle:
                    cv2.ellipse(vis_display, (dsx1 + dsw // 2, dsy1 + dsh // 2), (dsw // 2, dsh // 2), 0, 0, 360, (0, 255, 255), 2, cv2.LINE_AA)
                else:
                    cv2.rectangle(vis_display, (dsx1, dsy1), (dsx2, dsy2), (0, 255, 255), 2)

        if not self.is_image_mode and self.is_tracking_paused and active_trackers_count == 0:
            cv2.putText(vis_display, "PAUZA SLEDZENIA - BRAK ROZMYCIA", (20, 45), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 165, 255), 2, cv2.LINE_AA)

        img = cv2.cvtColor(vis_display, cv2.COLOR_BGR2RGB)
        im = Image.fromarray(img)
        tkimg = ImageTk.PhotoImage(image=im)
        self.video_label.imgtk = tkimg
        self.video_label.config(image=tkimg)

        pause_str = " | [PAUZA]" if self.is_tracking_paused else ""
        shape_str = "WIELOKĄT (LINE)" if self.line_var.get() else ("OWAL" if is_circle else "PROSTOKĄT")
        blur_mode_str = "PIXEL" if is_pixel else "GAUSS"
        zoom_str = f"Zoom: {self.zoom_level:.1f}x" if self.zoom_level > 1.0 else "Zoom: 1.0x"
        
        if self.line_var.get() and len(self.polygon_pts) > 0:
            line_status = f" | RYSOWANIE LINE: {len(self.polygon_pts)} pkt (2x klik zamyka, Prawy klik kasuje)"
        else:
            line_status = ""

        if self.is_image_mode:
            self.status_label.config(
                text=f"ZDJĘCIE | {zoom_str} | Twarzy: {active_trackers_count} | Kształt: {shape_str} | Rozmycie: {blur_mode_str}{line_status}"
            )
        else:
            self.status_label.config(
                text=f"Klatka: {idx}/{max(0, self.total_frames - 1)} | {zoom_str} | Aktywne twarze: {active_trackers_count}{pause_str} | Kształt: {shape_str} | Rozmycie: {blur_mode_str}{line_status}"
            )

        try:
            if not self.slider_dragging and not self.is_image_mode:
                self.slider.set(idx)
            self.frame_entry.delete(0, tk.END)
            self.frame_entry.insert(0, str(idx))
        except Exception:
            pass

    def on_slider_drag(self, val):
        if not self.is_image_mode:
            idx = int(float(val))
            self.show_frame(idx, heavy=False)

    def on_slider_release(self, event):
        if not self.is_image_mode:
            self.slider_dragging = False
            idx = int(self.slider.get())
            self.show_frame(idx, heavy=True, force_detect=True)

    def on_frame_entry(self, event):
        if self.is_image_mode:
            return
        try:
            v = int(self.frame_entry.get())
            v = max(0, min(v, self.total_frames - 1))
            self.show_frame(v, heavy=True, force_detect=True)
        except Exception:
            pass

    def step_frame(self, d):
        if not self.is_image_mode:
            self.show_frame(max(0, min(self.total_frames - 1, self.current_idx + d)), heavy=True)

    def export_media(self):
        if not self.input_path or not self.trackers:
            messagebox.showwarning("Brak danych", "Wybierz plik (wideo/zdjęcie) i zaznacz przynajmniej jedną twarz!")
            return

        if self.is_image_mode:
            self.export_image()
        else:
            self.export_video()

    def export_image(self):
        ext = os.path.splitext(self.input_path)[1].lower()
        if ext not in [".jpg", ".jpeg", ".png", ".bmp", ".webp"]:
            ext = ".jpg"
            
        default_name = "zamazane_" + os.path.basename(self.input_path)
        out_path = filedialog.asksaveasfilename(
            defaultextension=ext,
            filetypes=[("Zdjęcie", f"*{ext}"), ("JPG", "*.jpg"), ("PNG", "*.png")],
            initialfile=default_name
        )
        if not out_path:
            return

        frame = self.get_frame_cached(0)
        if frame is None:
            return
        out_img = frame.copy()

        is_bb = self.blackbox_var.get()
        is_circle = self.circle_var.get()
        is_pixel = self.pixel_mode_var.get()
        k_val = int(self.blur_slider.get())

        for tr in self.trackers:
            bbox = tr.get("last_good_bbox") or tr.get("last_bbox") or tr.get("init_bbox")
            if not bbox:
                continue
            x, y, bw, bh = bbox
            x1, y1 = max(0, x), max(0, y)
            x2, y2 = min(self.w, x + bw), min(self.h, y + bh)

            if x2 > x1 and y2 > y1:
                cx = x + bw // 2
                cy = y + bh // 2
                ax_w = bw // 2
                ax_h = bh // 2

                if tr.get("rel_poly"):
                    init_w = max(1, tr["init_bbox"][2])
                    init_h = max(1, tr["init_bbox"][3])
                    sx = bw / init_w
                    sy = bh / init_h
                    cur_poly = np.array([[int(x + rx * sx), int(y + ry * sy)] for rx, ry in tr["rel_poly"]], dtype=np.int32)
                    roi = out_img[y1:y2, x1:x2]
                    roi_poly = cur_poly - np.array([x1, y1])

                    mask = np.zeros(roi.shape[:2], dtype=np.uint8)
                    cv2.fillPoly(mask, [roi_poly], 255)

                    if is_bb:
                        out_img[y1:y2, x1:x2] = np.where(mask[:, :, None] == 255, 0, roi)
                    else:
                        if roi.size > 0:
                            processed_roi = self._apply_blur_or_pixel(roi, k_val, is_pixel)
                            out_img[y1:y2, x1:x2] = np.where(mask[:, :, None] == 255, processed_roi, roi)
                else:
                    if is_bb:
                        if is_circle:
                            cv2.ellipse(out_img, (cx, cy), (ax_w, ax_h), 0, 0, 360, (0, 0, 0), -1)
                        else:
                            out_img[y1:y2, x1:x2] = 0
                    else:
                        roi = out_img[y1:y2, x1:x2]
                        if roi.size > 0:
                            processed_roi = self._apply_blur_or_pixel(roi, k_val, is_pixel)
                            if is_circle:
                                mask = np.zeros(roi.shape[:2], dtype=np.uint8)
                                c_roi = ((x2 - x1) // 2, (y2 - y1) // 2)
                                cv2.ellipse(mask, c_roi, (ax_w, ax_h), 0, 0, 360, 255, -1)
                                out_img[y1:y2, x1:x2] = np.where(mask[:, :, None] == 255, processed_roi, roi)
                            else:
                                out_img[y1:y2, x1:x2] = processed_roi

        ext_out = os.path.splitext(out_path)[1]
        success, enc_img = cv2.imencode(ext_out, out_img)
        if success:
            enc_img.tofile(out_path)
            messagebox.showinfo("Gotowe", f"Zapisano przetworzone zdjęcie:\n{out_path}")
        else:
            messagebox.showerror("Błąd", "Nie udało się zapisać pliku graficznego.")

    def export_video(self):
        out_path = filedialog.asksaveasfilename(defaultextension=".mp4", filetypes=[("MP4", "*.mp4")], initialfile="zamazane.mp4")
        if not out_path:
            return
        threading.Thread(target=self.process_export, args=(out_path,), daemon=True).start()

    def _on_export_finished(self, out_path):
        self.progress["value"] = 100
        messagebox.showinfo("Gotowe", f"Film został pomyślnie wyeksportowany:\n{out_path}")

    def process_export(self, out_path):
        cap = cv2.VideoCapture(self.input_path)
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        out = cv2.VideoWriter(out_path, fourcc, self.fps, (self.w, self.h))
        total = self.total_frames

        exp = []
        for tr in self.trackers:
            exp.append({
                "id": tr["id"],
                "face_id": tr["face_id"],
                "start_frame": tr["start_frame"],
                "end_frame": tr.get("end_frame"),
                "tracker": None,
                "last_bbox": tr.get("init_bbox"),
                "init_bbox": tr.get("init_bbox"),
                "rel_poly": tr.get("rel_poly"),
                "active": False,
                "lost": 0
            })

        max_jump = self.jump_slider.get()
        is_bb = self.blackbox_var.get()
        is_circle = self.circle_var.get()
        is_pixel = self.pixel_mode_var.get()
        k_val = int(self.blur_slider.get())

        for idx in range(total):
            ret, frame = cap.read()
            if not ret:
                break

            clean_frame = frame.copy()
            boxes_to_apply = []

            for et in exp:
                if idx < et["start_frame"]:
                    continue
                if et.get("end_frame") is not None and idx > et["end_frame"]:
                    continue

                if idx == et["start_frame"]:
                    t = self.create_tracker(clean_frame, et["last_bbox"])
                    et["tracker"] = t
                    et["active"] = (t is not None)
                    if et["active"]:
                        boxes_to_apply.append((et["last_bbox"], et.get("rel_poly"), et.get("init_bbox")))
                elif et["active"] and et["tracker"]:
                    ok, box = et["tracker"].update(clean_frame)
                    if ok:
                        x, y, bw, bh = [int(v) for v in box]
                        px, py, pbw, pbh = et["last_bbox"]
                        dist = ((x + bw / 2 - (px + pbw / 2)) ** 2 + (y + bh / 2 - (py + pbh / 2)) ** 2) ** 0.5
                        ratio = max(bw / max(1, pbw), pbw / max(1, bw), bh / max(1, pbh), pbh / max(1, bh)) if pbw > 0 and pbh > 0 else 1

                        if dist > max_jump or ratio > 2.8:
                            et["lost"] += 1
                            if self.stop_on_loss_var.get() and et["lost"] > 2:
                                et["active"] = False
                            continue

                        et["last_bbox"] = (x, y, bw, bh)
                        et["lost"] = 0
                        boxes_to_apply.append(((x, y, bw, bh), et.get("rel_poly"), et.get("init_bbox")))
                    else:
                        et["lost"] += 1
                        if self.stop_on_loss_var.get() and et["lost"] > 5:
                            et["active"] = False

            for (box_tuple, rel_poly, init_b) in boxes_to_apply:
                x, y, bw, bh = box_tuple
                x1, y1 = max(0, x), max(0, y)
                x2, y2 = min(self.w, x + bw), min(self.h, y + bh)
                
                if x2 > x1 and y2 > y1:
                    cx = x + bw // 2
                    cy = y + bh // 2
                    ax_w = bw // 2
                    ax_h = bh // 2

                    if rel_poly and init_b:
                        init_w = max(1, init_b[2])
                        init_h = max(1, init_b[3])
                        sx = bw / init_w
                        sy = bh / init_h
                        cur_poly = np.array([[int(x + rx * sx), int(y + ry * sy)] for rx, ry in rel_poly], dtype=np.int32)
                        roi = frame[y1:y2, x1:x2]
                        roi_poly = cur_poly - np.array([x1, y1])

                        mask = np.zeros(roi.shape[:2], dtype=np.uint8)
                        cv2.fillPoly(mask, [roi_poly], 255)

                        if is_bb:
                            frame[y1:y2, x1:x2] = np.where(mask[:, :, None] == 255, 0, roi)
                        else:
                            if roi.size > 0:
                                processed_roi = self._apply_blur_or_pixel(roi, k_val, is_pixel)
                                frame[y1:y2, x1:x2] = np.where(mask[:, :, None] == 255, processed_roi, roi)
                    else:
                        if is_bb:
                            if is_circle:
                                cv2.ellipse(frame, (cx, cy), (ax_w, ax_h), 0, 0, 360, (0, 0, 0), -1)
                            else:
                                frame[y1:y2, x1:x2] = 0
                        else:
                            roi = frame[y1:y2, x1:x2]
                            if roi.size > 0:
                                processed_roi = self._apply_blur_or_pixel(roi, k_val, is_pixel)
                                if is_circle:
                                    mask = np.zeros(roi.shape[:2], dtype=np.uint8)
                                    c_roi = ((x2 - x1) // 2, (y2 - y1) // 2)
                                    cv2.ellipse(mask, c_roi, (ax_w, ax_h), 0, 0, 360, 255, -1)
                                    frame[y1:y2, x1:x2] = np.where(mask[:, :, None] == 255, processed_roi, roi)
                                else:
                                    frame[y1:y2, x1:x2] = processed_roi

            out.write(frame)

            if total > 0:
                prog_val = int((idx / total) * 100)
                self.root.after(0, lambda v=prog_val: self.progress.configure(value=v))

        cap.release()
        out.release()
        self.root.after(0, lambda: self._on_export_finished(out_path))


if __name__ == "__main__":
    root = tk.Tk()
    app = FaceBlurApp(root)
    root.mainloop()
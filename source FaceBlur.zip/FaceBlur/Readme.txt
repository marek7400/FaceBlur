

# ?? FaceBlur (Multi-Face Tracking & Anonymizer)

[![GitHub](https://img.shields.io/badge/GitHub-marek7400-blue?style=flat&logo=github)](https://github.com/marek7400?tab=repositories)
[![Platform](https://img.shields.io/badge/Platform-Windows-0078D6?style=flat&logo=windows)](https://github.com/marek7400)
[![Python](https://img.shields.io/badge/Python-3.8%2B-brightgreen?style=flat&logo=python)](https://www.python.org/)
[![OpenCV](https://img.shields.io/badge/OpenCV-DNN%20%7C%20CSRT-orange?style=flat&logo=opencv)](https://opencv.org/)

Nowoczesne, lekkie i w 100% lokalne narz�dzie dla systemu Windows do automatycznego i r�cznego zamazywania/anonimizacji **wielu twarzy jednocze�nie na wideo oraz statycznych zdj�ciach**.

Program zosta� zoptymalizowany pod k�tem pracy na standardowych procesorach (CPU) bez potrzeby posiadania pot�nej karty graficznej. Posiada wbudowany bufor trajektorii (brak zaci�� przy cofaniu wideo), 4 zaawansowane silniki detekcji AI ONNX, p�ynny zoom z przesuwaniem kadru (Pan) oraz mo�liwo�� tworzenia masek prostok�tnych, owalnych i wielok�tnych (`LINE`).

---

## ?? Spis tre�ci
1. [G��wne cechy](#-g��wne-cechy)
2. [Pobieranie i uruchomienie (.EXE)](#-pobieranie-i-uruchomienie-exe)
3. [Uruchomienie ze �r�de� (Python)](#-uruchomienie-ze-�r�de�-python)
4. [Szczeg�owy opis funkcji i interfejsu](#-szczeg�owy-opis-funkcji-i-interfejsu)
5. [Skr�ty klawiszowe i sterowanie mysz�](#-skr�ty-klawiszowe-i-sterowanie-mysz�)
6. [Przegl�d modeli AI (Detektory twarzy)](#-przegl�d-modeli-ai-detektory-twarzy)
7. [Tryby zamazywania i kszta�ty](#-tryby-zamazywania-i-kszta�ty)
8. [Rozwi�zywanie problem�w (FAQ)](#-rozwi�zywanie-problem�w-faq)
---

## ?? G��wne cechy

* **Wsparcie dla wideo i zdj��:** Anonimizacja plik�w wideo (`.mp4`, `.mov`, `.avi`, `.mkv`, `.wmv`) oraz fotografii (`.jpg`, `.jpeg`, `.png`, `.bmp`, `.webp`).
* **�ledzenie wielu twarzy naraz (Multi-Face):** Niezale�ne �ledzenie wielu os�b w kadrze z osobnymi identyfikatorami (Twarz 1, Twarz 2 itd.).
* **Brak sztucznych obw�dek:** Zamazane obszary wtapiaj� si� czysto w otoczenie bez widocznych kolorowych obrys�w.
* **Hybrydowe oznaczanie (AUTO + MANUAL na ka�dej klatce):** 
  * Klikni�cie zielonej ramki AI $\rightarrow$ natychmiastowe �ledzenie automatyczne.
  * Przeci�gni�cie lewym przyciskiem myszy $\rightarrow$ r�czne dodanie w�asnej ramki.
  * Tryb **LINE** $\rightarrow$ swobodne rysowanie wielok�t�w klikni�cie po klikni�ciu.
* **Elastyczna korekta (Handover per twarz):** Klikni�cie nowej pozycji �ledzonej twarzy automatycznie ko�czy jej stary segment i p�ynnie wznawia nowy.
* **Pami�� trajektorii (Trajectory Caching):** B�yskawiczne przewijanie osi czasu wstecz bez ponownego przeliczania tracker�w i bez zamra�ania programu.
* **Pauza �ledzenia (PAUSE / RESUME):** Mo�liwo�� czasowego przerwania zamazywania (np. gdy posta� chowa si� za �cian�) i wznowienia go w odpowiedniej klatce.
* **Wbudowany podgl�d z Zoomem (do 12x):** Przybli�anie k�kiem myszy i przesuwanie kadru (Pan) prawym przyciskiem myszy. Kontrolki nie powi�kszaj� si� do gigantycznych rozmiar�w przy zoomie.

---

## ?? Pobieranie i uruchomienie (.EXE)

Aplikacja jest dystrybuowana jako **pojedynczy, w pe�ni samowystarczalny plik wykonywalny Windows**:

1. Pobierz plik **`FaceBlurTool.exe`** z zak�adki Releases lub skompiluj go samodzielnie skryptem `make_exe.bat`.
2. Umie�� plik w dowolnym folderze na dysku.
3. Uruchom program dwuklikiem � wszystkie 4 silniki AI s� zaszyte wewn�trz pliku, wi�c aplikacja nie wymaga instalowania Pythona ani �adnych zewn�trznych bibliotek.

---

## ?? Uruchomienie ze �r�de� (Python)

Je�li wolisz uruchomi� aplikacj� bezpo�rednio w �rodowisku Pythona:

```bash
# 1. Klonowanie repozytorium
git clone https://github.com/marek7400/face-blur-tool.git
cd face-blur-tool

# 2. Instalacja zale�no�ci
pip install -r requirements.txt

# 3. Uruchomienie aplikacji
python face_blur_v35_multi_model.py

lub zainstaluj Python (3.13) i uruchom plik run_v35_multi-model.bat
```

Wymagania w `requirements.txt`:
```text
opencv-contrib-python>=4.8.0
Pillow>=9.0.0
numpy
```

---

## ?? Szczeg�owy opis funkcji i interfejsu

### 1. G�rny pasek narz�dzi
* **Wybierz wideo:** Otwiera plik filmowy, �aduje klatki i konfiguruje o� czasu.
* **Wybierz zdj�cie:** Wycisza o� czasu i prze��cza program w tryb obr�bki pojedynczego zdj�cia w pe�nej rozdzielczo�ci.
* **Model (Lista rozwijana):** Prze��czanie w locie silnika AI (YuNet, SCRFD 500M, SCRFD 2.5G, YOLO-Face Nano).
* **Wska�...:** Pozwala wskaza� z dysku dowolny inny plik `.onnx` zgodny z architektur�.
* **Zama� wszystkie zielone:** Zaczyna �ledzi� wszystkie twarze wykryte przez AI na bie��cej klatce jednym klikni�ciem.
* **? PAUSE:** Zamyka aktywny segment twarzy na poprzedniej klatce. Na bie��cej klatce i kolejnych rozmycie zostaje wy��czone.
* **? RESUME:** Wznawia �ledzenie twarzy z listy od bie��cej klatki (tworzy nowy segment).
* **CIRCLE (owal):** Zmienia kszta�t maski z prostok�tnej na owaln� (elipsa).
* **BLACKBOX:** Zamiast rozmycia nak�ada pe�ne zaczernienie (cenzur�).
* **LINE (wielok�t):** W��cza tryb obrysowywania kszta�t�w wieloma liniami.
* **Stop gdy zgubi:** Zatrzymuje �ledzenie danej twarzy, je�li obiekt wykona zbyt gwa�towny skok lub zniknie z kadru.
* **?? ZOOM 1:1:** Natychmiast resetuje powi�kszenie i centruje ca�y kadr.
* **Cofnij:** Cofa ostatnio dodany segment lub przej�cie �ledzenia.
* **Wyczy��:** Resetuje wszystkie ramki i ca�� o� czasu do zera.
* **Eksportuj / Zapisz:** Zapisuje gotowy film `.mp4` lub przetworzone zdj�cie.

### 2. O� czasu (D� ekranu)
* **`|<< Pocz�tek`:** B�yskawiczny skok do klatki `0`.
* **Suwak osi czasu:** Przesuwanie klatek. Przy szybkim przeci�ganiu program wy�wietla podgl�d lekki, a pe�ne przeliczenie wykonuje po zwolnieniu przycisku myszy.
* **`Koniec >>|`:** B�yskawiczny skok do ostatniej klatki filmu.
* **Pole numeryczne klatki:** Pozwala wpisa� numer klatki i wcisn�� `Enter`.
* **Si�a rozmycia:** P�ynna regulacja od 15 do 151 (steruje stopniem rozmycia Gaussa lub rozmiarem klock�w w PIXEL MODE).
* **PIXEL MODE:** Prze��cza rozmycie na styl pikselowej mozaiki retro.
* **Tolerancja skoku (px):** Maksymalny dopuszczalny ruch twarzy mi�dzy klatkami, po przekroczeniu kt�rego tracker uznaje obiekt za zgubiony (ochrona przed dryfem).

### 3. Panel boczny (Prawa strona)
* Informacje o aktywnym modelu AI, rozdzielczo�ci i liczbie klatek.
* Przewijalna lista wszystkich segment�w (`Twarz X [ID Y]`).
* Przyciski przy ka�dym segmencie:
  * **`ID�`** � przenosi suwak dok�adnie do klatki startowej danego segmentu.
  * **`X`** � trwale usuwa wskazany segment.

---

## ?? Metody zaznaczania i edycji

```
-�������������������������������������������������������������������������
- AUTO: Kliknij lewym zielon� ramk� AI                                  -
- MANUAL: Naci�nij lewy i przeci�gnij prostok�t/owal                    -
- LINE: Zaznacz 'LINE', klikaj punkty, zako�cz 2x klikni�ciem           -
- PRZESUNI�CIE: Chwy� za ��t� ikon� 4 strza�ek na �rodku ramki          -
- ROZMIAR: Chwy� za kraw�d� lub naro�nik ramki                           -
L������������������������������������������������������������������������-
```

* **Korekta w trakcie filmu (Handover):** Je�li na klatce 100 tracker lekko zjecha� z twarzy, wystarczy klikn�� now� zielon� ramk� AI lub narysowa� now� r�cznie w pobli�u. Program automatycznie zako�czy stary segment na klatce 99 i zacznie nowy od klatki 100.
* **Przesuwanie i skalowanie ramki:** 
  * Najed� na �rodek dowolnej aktywnej ramki � pojawi si� ikona z 4 strza�kami. Wci�nij lewy przycisk i przesu�.
  * Najed� na kraw�d� lub naro�nik � kursor zmieni si� w strza�ki skalowania. Wci�nij lewy przycisk i rozci�gnij/zmniejsz obszar.
  * Dzia�a to r�wnie� przy w��czonym trybie `LINE` (kontrole edycji maj� pierwsze�stwo przed stawianiem nowych punkt�w).

---

## ? Skr�ty klawiszowe i sterowanie mysz�

| Klawisz / Przycisk | Akcja |
| :--- | :--- |
| **Lewy przycisk myszy** | Klikni�cie w zielon� ramk� (AUTO) / Przeci�gni�cie (MANUAL) |
| **Lewy przycisk (�rodek ramki)** | Chwycenie i przesuni�cie ca�ej ramki |
| **Lewy przycisk (kraw�d� ramki)** | Zmiana rozmiaru ramki w wybranym kierunku |
| **Podw�jny klik (Lewy)** | Zamkni�cie i utworzenie wielok�ta w trybie `LINE` |
| **Prawy przycisk myszy (klik)** | Usuni�cie pojedynczej ramki pod kursorem (tak�e anulowanie rysowania `LINE`) |
| **Prawy przycisk myszy (przeci�gni�cie)** | **Chwycenie i przesuwanie obrazu (Pan)** przy powi�kszeniu (`Zoom > 1.0x`) |
| **K�ko myszy (Scroll)** | P�ynny Zoom w stron� kursora (do 12x) / Oddalanie |
| **�rodkowy przycisk myszy / Shift + LPM** | Alternatywne przesuwanie powi�kszonego obrazu (Pan) |
| **Strza�ka w prawo (`�`)** | Nast�pna klatka (+1) |
| **Strza�ka w lewo (`�`)** | Poprzednia klatka (-1) |
| **Shift + Strza�ka w prawo** | Skok w prz�d o 10 klatek (+10) |
| **Shift + Strza�ka w lewo** | Skok w ty� o 10 klatek (-10) |
| **Strza�ka w g�r� (`^`)** | Skok w prz�d o 30 klatek (+30) |
| **Strza�ka w d� (`�`)** | Skok w ty� o 30 klatek (-30) |
| **Klawisz `Delete`** | Cofni�cie / usuni�cie ostatniego segmentu |

---

## ?? Przegl�d modeli AI (Detektory twarzy)

Program pozwala na dynamiczny wyb�r spo�r�d 4 modeli ONNX:

```
[ YuNet ] ���������� Lekki, wbudowany w OpenCV (~300 KB), bardzo szybki na CPU
[ SCRFD 500M ] ����� Zoptymalizowany pod CPU (~2.4 MB), demon pr�dko�ci
[ SCRFD 2.5G ] ����� Najlepszy balans dok�adno�ci do pr�dko�ci (~3.2 MB)
[ YOLO-Face Nano ] � �wietny przy profilach 90� i trudnych k�tach (~6.0 MB)
```

| Model | Waga | Rekomendowane zastosowanie |
| :--- | :--- | :--- |
| **YuNet** | ~335 KB | Szybkie wykrywanie twarzy frontalnych i lekko obr�conych. |
| **SCRFD 500M** | ~2.4 MB | Bardzo s�abe procesory; sceny z wieloma ma�ymi twarzami. |
| **SCRFD 2.5G** | ~3.2 MB | **Zalecany domy�lny:** znakomity stosunek dok�adno�ci do szybko�ci na CPU. |
| **YOLO-Face (Nano)** | ~6.0 MB | Twarze w pe�nym profilu (90�), mocno odchylone g�owy, czapki i okulary. |
| **Haar Cascade** | ~900 KB | Tradycyjny algorytm OpenCV dzia�aj�cy jako automatyczny fallback w razie braku plik�w `.onnx`. |

---

## ?? Tryby zamazywania i kszta�ty

1. **Gaussian Blur (Domy�lny):** P�ynne, estetyczne rozmycie plam� Gaussa. Si�� ustala suwak `Si�a rozmycia`.
2. **PIXEL MODE:** Mozaika pikselowa. Rozmiar pikseli ro�nie wraz z warto�ci� suwaka rozmycia.
3. **BLACKBOX:** Klasyczna, solidna cenzura czarnym prostok�tem lub owalem.
4. **Maska CIRCLE (Owal):** Twarze maskowane s� elips� wyci�t� precyzyjnie w kadrze.
5. **Maska LINE (Wielok�t):** R�cznie zdefiniowany wielok�t dopasowany do nieregularnych kszta�t�w (np. tatua�, tablica rejestracyjna, specyficzny kadr).

---

## ? Rozwi�zywanie problem�w (FAQ)

#### 1. Czy program wymaga zewn�trznej karty graficznej?
Nie. Wszystkie algorytmy i sieci neuronowe ONNX zosta�y zoptymalizowane pod instrukcje wektorowe procesora (CPU). Program dzia�a p�ynnie nawet na zintegrowanych uk�adach graficznych i starszych komputerach.

#### 2. Windows Defender / SmartScreen wy�wietla ostrze�enie przy uruchomieniu pliku .EXE
Jest to standardowe zachowanie filtru Windows SmartScreen dla nowo skompilowanych plik�w `.exe` bez p�atnego certyfikatu cyfrowego EV:
* Kliknij **�Wi�cej informacji�**, a nast�pnie **�Uruchom mimo to�**.
* Program nie zawiera �adnego z�o�liwego kodu (kod �r�d�owy jest w 100% jawny i otwarty).

#### 3. Program nie wykrywa twarzy obr�conej ca�kowicie bokiem (profil 90�)
* Zmie� model z listy na **YOLO-Face (Nano)** lub **SCRFD 2.5G** � radz� sobie ze skrajnymi obrotami znacznie lepiej ni� YuNet.
* Alternatywnie: po prostu narysuj ramk� r�cznie (przeci�gaj�c lewym przyciskiem myszy) � od tego momentu tracker CSRT poprowadzi twarz samodzielnie.

#### 4. Jak cofn�� si� w filmie bez zacinania obrazu?
Dzi�ki wdro�eniu pami�ci trajektorii (`traj cache`) cofanie w wideo jest natychmiastowe. Pami�taj jednak, �e podczas bardzo szybkiego przesuwania suwaka w prz�d program celowo nie przelicza AI dla ka�dej klatki po�redniej � zwolnij suwak w docelowym miejscu, aby program dokona� pe�nej analizy.
```
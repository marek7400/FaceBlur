
#  FaceBlur (Multi-Face Tracking & Anonymizer) � v1.36

[![GitHub](https://img.shields.io/badge/GitHub-marek7400-blue?style=flat&logo=github)](https://github.com/marek7400?tab=repositories)
[![Release](https://img.shields.io/badge/Wersja-1.36-success?style=flat)](https://github.com/marek7400)
[![Platform](https://img.shields.io/badge/Platform-Windows-0078D6?style=flat&logo=windows)](https://github.com/marek7400)
[![Python](https://img.shields.io/badge/Python-3.8%2B-brightgreen?style=flat&logo=python)](https://www.python.org/)
[![OpenCV](https://img.shields.io/badge/OpenCV-DNN%20%7C%20CSRT-orange?style=flat&logo=opencv)](https://opencv.org/)
[![FFmpeg](https://img.shields.io/badge/Audio-FFmpeg%20Pass--Through-red?style=flat&logo=ffmpeg)](https://ffmpeg.org/)

Nowoczesne, lekkie i w 100% lokalne narz�dzie dla systemu Windows do automatycznego i r�cznego zamazywania/anonimizacji **wielu twarzy jednocze�nie na wideo oraz statycznych zdj�ciach**.

Aplikacja zosta�a zoptymalizowana pod k�tem pracy na standardowych procesorach (CPU) bez potrzeby posiadania dedykowanej karty graficznej. Posiada wbudowany bufor trajektorii (brak zaci�� przy cofaniu wideo), 4 zaawansowane silniki detekcji AI ONNX, p�ynny zoom z przesuwaniem kadru (Pan), mi�kkie wtapianie kraw�dzi (Feathering), pe�ne zachowanie oryginalnego d�wi�ku (FFmpeg), tryb ciemny/jasny oraz mo�liwo�� tworzenia masek prostok�tnych, owalnych i wielok�tnych (`LINE`).

---

## Spis tre�ci
1. [Nowo�ci w wersji 1.36](#-nowo�ci-w-wersji-136)
2. [G��wne cechy](#-g��wne-cechy)
3. [Wymagania i integracja z FFmpeg](#-wymagania-i-integracja-z-ffmpeg-d�wi�k-w-wideo)
4. [Pobieranie i uruchomienie (.EXE)](#-pobieranie-i-uruchomienie-exe)
5. [Uruchomienie ze �r�de� (Python)](#-uruchomienie-ze-�r�de�-python)
6. [Szczeg�owy opis interfejsu](#-szczeg�owy-opis-interfejsu)
7. [Metody zaznaczania i edycji masek](#-metody-zaznaczania-i-edycji-masek)
8. [Skr�ty klawiszowe i sterowanie mysz�](#-skr�ty-klawiszowe-i-sterowanie-mysz�)
9. [Przegl�d modeli AI (Detektory twarzy)](#-przegl�d-modeli-ai-detektory-twarzy)
10. [Tryby zamazywania i kszta�ty](#-tryby-zamazywania-i-kszta�ty)
11. [Rozwi�zywanie problem�w (FAQ)](#-rozwi�zywanie-problem�w-faq)

---

##  Nowo�ci w wersji 1.36

*  **Pe�ne zachowanie �cie�ki d�wi�kowej w filmach:** Dzi�ki integracji z narz�dziem **FFmpeg**, eksportowane wideo zachowuje 100% oryginalnego d�wi�ku (`audio pass-through` bez utraty jako�ci).
*  **Wtapianie kraw�dzi maski (Feathering):** P�ynne, zmi�kczone przej�cie tonalne mi�dzy rozmytym obiektem a t�em. Sterowane dedykowanym suwakiem w zakresie 0�100%.
*  **Prze��cznik motywu Jasny / Ciemny (Dark Mode):** Nowy przycisk ` / ` w g�rnym pasku dynamicznie dopasowuje palet� barw ca�ego interfejsu.
*  **Dedykowane okno post�pu eksportu:** Procentowy licznik (`%`), pasek post�pu oraz informacja o aktualnie renderowanej klatce w osobnym oknie modalnym.
*  **Wszystkie okna i komunikaty wycentrowane:** Komunikaty informacyjne, pytania, b��dy oraz pasek eksportu otwieraj� si� idealnie na �rodku ekranu.
*  **Ulepszone suwaki i pami�� ustawie�:**
  * Warto�� liczbowa oraz nazwa wy�wietlane s� bezpo�rednio **nad suwakiem** (wzorem osi czasu).
  * Tolerancja skoku zwi�kszona do **300 px**.
  * Wyd�u�one suwaki dla wi�kszej precyzji.
  * Automatyczny zapis ustawie� do pliku `settings.json` i ich przywracanie przy starcie.
*  **Uporz�dkowany uk�ad:** Prze��czniki kszta�t�w (`CIRCLE`, `BLACKBOX`, `LINE`, `PIXEL MODE`) zosta�y przeniesione do dolnego panelu parametr�w.

---

## G��wne cechy

* **Wsparcie dla wideo i zdj��:** Anonimizacja plik�w filmowych (`.mp4`, `.mov`, `.avi`, `.mkv`, `.wmv`) oraz fotografii (`.jpg`, `.jpeg`, `.png`, `.bmp`, `.webp`).
* **�ledzenie wielu twarzy naraz (Multi-Face):** Niezale�ne �ledzenie wielu os�b w kadrze z osobnymi identyfikatorami (Twarz 1, Twarz 2 itd.).
* **Brak sztucznych obw�dek:** Zamazane obszary wtapiaj� si� w otoczenie bez widocznych kolorowych obrys�w na finalnym materiale.
* **Hybrydowe oznaczanie (AUTO + MANUAL na ka�dej klatce):** 
  * Klikni�cie zielonej ramki AI $\rightarrow$ natychmiastowe �ledzenie automatyczne.
  * Przeci�gni�cie lewym przyciskiem myszy $\rightarrow$ r�czne dodanie w�asnej ramki.
  * Tryb **LINE** $\rightarrow$ swobodne rysowanie wielok�t�w klikni�cie po klikni�ciu.
* **Elastyczna korekta (Handover per twarz):** Klikni�cie nowej pozycji �ledzonej twarzy automatycznie ko�czy jej stary segment i p�ynnie wznawia nowy.
* **Pami�� trajektorii (Trajectory Caching):** B�yskawiczne przewijanie osi czasu wstecz bez ponownego przeliczania tracker�w i bez zamra�ania programu.
* **Pauza �ledzenia (PAUSE / RESUME):** Mo�liwo�� czasowego przerwania zamazywania (np. gdy posta� chowa si� za przeszkod�) i wznowienia go w dowolnej klatce.
* **Wbudowany podgl�d z Zoomem (do 12x):** Przybli�anie k�kiem myszy i przesuwanie kadru (Pan) prawym przyciskiem myszy. Kontrolki zachowuj� sta�y, por�czny rozmiar na ekranie.

---

## Wymagania i integracja z FFmpeg (D�wi�k w wideo)

Aby program m�g� scali� oryginaln� �cie�k� d�wi�kow� z wyeksportowanym wideo, potrzebuje narz�dzia **FFmpeg**:

1. Program przy starcie automatycznie sprawdza, czy w jego katalogu znajduje si� plik `ffmpeg.exe` (lub czy FFmpeg jest zainstalowany w systemowej zmiennej `PATH`).
2. Je�li pliku brakuje, wy�wietli si� okno z bezpo�rednimi odno�nikami do pobrania:
   * [Oficjalna paczka GPL (BtbN Releases)](https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip)
   * [Alternatywna paczka Gyan.dev](https://www.gyan.dev/ffmpeg/builds/ffmpeg-git-full.7z)
3. **Instalacja:** Wystarczy rozpakowa� archiwum i skopiowa� pojedynczy plik **`ffmpeg.exe`** bezpo�rednio do folderu z programem `FaceBlurTool.exe`.
4. *Uwaga:* W przypadku braku FFmpeg program nadal wyeksportuje zamazany plik wideo, lecz b�dzie on pozbawiony �cie�ki d�wi�kowej.

---

## Pobieranie i uruchomienie (.EXE)

Aplikacja jest dystrybuowana jako **gotowy plik wykonywalny Windows**:

1. Pobierz plik **`FaceBlur.exe`** z zak�adki **Releases**.
2. Umie�� plik w dowolnym folderze na dysku (zalecane umieszczenie obok pliku `ffmpeg.exe`).
3. Uruchom program dwuklikiem � silniki AI s� wbudowane lub �adowane z folderu programu, program nie wymaga instalowania �rodowiska Python.

---

## Uruchomienie ze �r�de� (Python)

Je�li wolisz uruchomi� aplikacj� w czystym �rodowisku Pythona (zalecany Python 3.10 � 3.13):

```bash
# 1. Sklonuj repozytorium
git clone https://github.com/marek7400/face-blur-tool.git
cd face-blur-tool

# 2. Zainstaluj zale�no�ci
pip install -r requirements.txt

# 3. Uruchom aplikacj�
python face_blur_app.py
```

Zawarto�� `requirements.txt`:
```text
opencv-contrib-python>=4.8.0
Pillow>=9.0.0
numpy
```

---

## Szczeg�owy opis interfejsu

### 1. G�rny pasek narz�dzi
* **Wybierz wideo:** Otwiera plik filmowy, �aduje klatki i konfiguruje o� czasu.
* **Wybierz zdj�cie:** Wycisza o� czasu i prze��cza program w tryb obr�bki pojedynczego zdj�cia.
* **Model (Lista rozwijana):** Prze��czanie w locie silnika AI (YuNet, SCRFD 500M, SCRFD 2.5G, YOLO-Face Nano).
* **Wska�...:** Pozwala wskaza� plik `.onnx` z dysku.
* **Zama� wszystkie zielone:** Zaczyna �ledzi� wszystkie twarze wykryte przez AI na bie��cej klatce jednym klikni�ciem.
* **? PAUSE:** Ko�czy �ledzenie twarzy na poprzedniej klatce (wy��cza maskowanie od bie��cej klatki).
* **? RESUME:** Wznawia �ledzenie twarzy od bie��cej klatki.
* **Stop gdy zgubi:** Zatrzymuje �ledzenie danej twarzy w razie gwa�townego skoku lub opuszczenia kadru.
* ** ZOOM 1:1:** Resetuje powi�kszenie i wy�rodkowuje widok.
* **Cofnij:** Cofa ostatnio utworzony segment �ledzenia.
* **Wyczy��:** Resetuje wszystkie trackery i czy�ci o� czasu.
* ** / :** Natychmiastowe prze��czenie motywu ciemnego/jasnego.
* **Eksportuj / Zapisz:** Uruchamia proces renderowania z oknem post�pu.

### 2. Dolny panel kontrolny
* **O� czasu:** P�ynna nawigacja po klatkach (`|<< Pocz�tek`, suwak z numerem klatki, `Koniec >>|`, pole bezpo�redniego wpisu).
* **Suwak �Rozmycie� (0�100):** Regulacja si�y rozmycia Gaussa lub rozmiaru blok�w mozaiki.
* **Suwak �Wtapianie� (0�100):** P�ynne zmi�kczanie kraw�dzi maski (brak ostrych odci��).
* **Suwak �Tolerancja skoku� (0�300):** Maksymalny dopuszczalny ruch obiektu w pikselach mi�dzy klatkami (zabezpieczenie przed dryfem trackera CSRT).
* **Prze��czniki kszta�t�w i tryb�w:**
  * `CIRCLE (owal)` � maska w kszta�cie elipsy.
  * `BLACKBOX` � pe�na cenzura czarn� plam�.
  * `LINE (wielok�t)` � r�czne wyznaczanie punkt�w nieregularnego kszta�tu.
  * `PIXEL MODE` � zamiana rozmycia Gaussa na pikseloz� retro.

### 3. Prawy panel boczny
* Status aktywnego silnika AI oraz parametry wczytanego pliku.
* Przewijalna lista segment�w (`Twarz X [ID Y]`):
  * **`ID�`** � przenosi o� czasu do klatki startowej wybranego segmentu.
  * **`X`** � bezpowrotnie usuwa dany segment �ledzenia.

---

## Metody zaznaczania i edycji masek

```
-�������������������������������������������������������������������������
- � AUTO: Kliknij lewym przyciskiem myszy w zielon� ramk� AI             -
- � MANUAL: Przeci�gnij lewym przyciskiem, tworz�c prostok�t/owal        -
- � LINE: Zaznacz 'LINE', klikaj punkty, zako�cz 2x klikni�ciem          -
- � PRZESUNI�CIE: Chwy� za ��t� ikon� celownika na �rodku ramki         -
- � ROZMIAR: Chwy� za kraw�d� lub naro�nik ramki                         -
L������������������������������������������������������������������������-
```

* **Korekta pozycji (Handover):** Je�li tracker zjedzie z twarzy na dalszych klatkach, wystarczy klikn�� now� zielon� ramk� lub narysowa� now�. Program zarchiwizuje dotychczasow� tras� i p�ynnie podejmie �ledzenie od nowej pozycji.
* **Interaktywne uchwyty:** Na aktywnej ramce dost�pne s� punkty zmiany rozmiaru oraz centralny uchwyt przesuwania � dzia�aj� one niezale�nie od powi�kszenia (Zoom).

---

## Skr�ty klawiszowe i sterowanie mysz�

| Klawisz / Przycisk | Akcja |
| :--- | :--- |
| **Lewy przycisk myszy (LPM)** | Klikni�cie w ramk� AI (AUTO) / Przeci�gni�cie (MANUAL) |
| **LPM (�rodek ramki)** | Przesuni�cie po�o�enia maski |
| **LPM (kraw�d� / naro�nik)** | Zmiana szeroko�ci i wysoko�ci maski |
| **Podw�jny klik (LPM)** | Zamkni�cie wielok�ta w trybie `LINE` |
| **Prawy przycisk myszy (klik)** | Usuni�cie maski pod kursorem / Anulowanie punkt�w `LINE` |
| **Prawy przycisk myszy (przeci�gni�cie)** | **Przesuwanie widoku (Pan)** przy powi�kszeniu (`Zoom > 1.0x`) |
| **K�ko myszy (Scroll)** | P�ynny Zoom w stron� kursora (do 12x) / Oddalanie |
| **�rodkowy przycisk myszy / Shift + LPM** | Alternatywne przesuwanie powi�kszonego kadru (Pan) |
| **Strza�ka w prawo (`�`)** | Nast�pna klatka (+1) |
| **Strza�ka w lewo (`�`)** | Poprzednia klatka (-1) |
| **Shift + Strza�ka w prawo** | Skok w prz�d o 10 klatek (+10) |
| **Shift + Strza�ka w lewo** | Skok w ty� o 10 klatek (-10) |
| **Strza�ka w g�r� (`^`)** | Skok w prz�d o 30 klatek (+30) |
| **Strza�ka w d� (`�`)** | Skok w ty� o 30 klatek (-30) |
| **Klawisz `Delete`** | Usuni�cie ostatniego segmentu |

---

## Przegl�d modeli AI (Detektory twarzy)

Mo�liwo�� wyboru silnika detekcji w zale�no�ci od specyfiki materia�u i mocy procesora:

```
[ YuNet ] ���������� Lekki, zintegrowany z OpenCV (~335 KB), bardzo szybki na CPU
[ SCRFD 500M ] ����� Bardzo szybki (~2.4 MB), idealny do ma�ych twarzy w t�umie
[ SCRFD 2.5G ] ����� Najlepszy stosunek precyzji do obci��enia procesora (~3.2 MB)
[ YOLO-Face Nano ] � Niezr�wnany przy profilach 90�, nakryciach g�owy i trudnych k�tach (~6.0 MB)
```

| Model | Waga | Zastosowanie |
| :--- | :--- | :--- |
| **YuNet** | ~335 KB | Szybkie wykrywanie twarzy frontalnych i lekko obr�conych. |
| **SCRFD 500M** | ~2.4 MB | S�absze procesory, uj�cia szerokok�tne z du�� liczb� os�b. |
| **SCRFD 2.5G** | ~3.2 MB | **Rekomendowany:** optymalny balans skuteczno�ci i pr�dko�ci. |
| **YOLO-Face (Nano)** | ~6.0 MB | Twarze w profilu (90�), mocne przechy�y, okulary i maski. |
| **Haar Cascade** | ~900 KB | Wbudowany silnik awaryjny (fallback) na wypadek braku plik�w ONNX. |

---

## Tryby zamazywania i kszta�ty

1. **Gaussian Blur:** Klasyczne, g�adkie rozmycie Gaussa o sile regulowanej suwakiem *Rozmycie*.
2. **Feathering (Wtapianie):** Zmi�kcza kraw�dzie rozmycia, eliminuj�c odcinaj�ce si� linie maski.
3. **PIXEL MODE:** Pikselowa mozaika. Wielko�� blok�w dopasowuje si� do suwaka rozmycia.
4. **BLACKBOX:** Kryj�ca czarna cenzura (prostok�tna lub eliptyczna).
5. **Maska CIRCLE (Owal):** Naturalne, owalne dopasowanie maski do obrysu g�owy.
6. **Maska LINE (Wielok�t):** Precyzyjne obrysowanie nieregularnych element�w (tatua�e, logotypy, tablice rejestracyjne).

---

## Rozwi�zywanie problem�w (FAQ)

#### 1. Dlaczego wyeksportowany film nie ma d�wi�ku?
Upewnij si�, �e plik `ffmpeg.exe` znajduje si� w tym samym folderze co plik wykonywalny programu. Program poinformuje o braku pliku stosownym komunikatem przy starcie.

#### 2. Windows SmartScreen wy�wietla ostrze�enie przy uruchomieniu pliku .EXE
Jest to standardowe zachowanie filtru Windows Defender dla nowo skompilowanych aplikacji bez p�atnego certyfikatu:
* Kliknij **�Wi�cej informacji�**, a nast�pnie wybierz **�Uruchom mimo to�**.
* Aplikacja jest w 100% bezpieczna, nie ��czy si� z internetem i dzia�a wy��cznie lokalnie na Twoim komputerze.

#### 3. Posta� obraca si� ty�em lub profilem i tracker gubi twarz
* Prze��cz model na **YOLO-Face (Nano)** lub **SCRFD 2.5G**.
* Zwi�ksz warto�� suwaka **Tolerancja skoku** (np. do 180�220 px).
* W razie zerwania �ledzenia zatrzymaj film, narysuj ramk� r�cznie (LPM) i kontynuuj odtwarzanie.

#### 4. Gdzie zapisywane s� moje ustawienia suwak�w?
Warto�ci suwak�w (*Rozmycie*, *Wtapianie*, *Tolerancja skoku*) s� automatycznie zapisywane w pliku `settings.json` w folderze programu przy ka�dym zamkni�ciu okna.